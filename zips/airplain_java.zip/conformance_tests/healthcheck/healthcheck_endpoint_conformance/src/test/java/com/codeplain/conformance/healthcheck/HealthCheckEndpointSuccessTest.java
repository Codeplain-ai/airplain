package com.codeplain.conformance.healthcheck;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Conformance test for the /healthcheck endpoint.
 * This test verifies that the App returns a 200 OK status when healthy.
 */
@SpringBootTest(
    classes = com.codeplain.messaging.MessagingApplication.class,
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT
)
public class HealthCheckEndpointSuccessTest {

    private static final Logger logger = LoggerFactory.getLogger(HealthCheckEndpointSuccessTest.class);

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    public void testHealthCheckEndpointReturns200() {
        logger.info("Starting HealthCheckEndpointSuccessTest...");
        
        String url = "/healthcheck";
        logger.info("Executing GET request to: {}", url);

        try {
            ResponseEntity<Void> response = restTemplate.getForEntity(url, Void.class);

            logger.info("Received response status: {}", response.getStatusCode());
            
            assertEquals(HttpStatus.OK, response.getStatusCode(), 
                "The /healthcheck endpoint must return HTTP 200 OK when the application is running.");

            logger.info("Health check verification successful.");
        } catch (Exception e) {
            logger.error("An error occurred during the health check request: {}", e.getMessage(), e);
            throw e;
        }
    }
}