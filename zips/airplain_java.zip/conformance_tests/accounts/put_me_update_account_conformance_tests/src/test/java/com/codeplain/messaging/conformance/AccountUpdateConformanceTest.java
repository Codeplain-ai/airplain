package com.codeplain.messaging.conformance;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = com.codeplain.messaging.MessagingApplication.class)
public class AccountUpdateConformanceTest {
    private static final Logger log = LoggerFactory.getLogger(AccountUpdateConformanceTest.class);

    @Autowired
    private TestRestTemplate restTemplate;

    private String registerAndGetToken(String username, String password) {
        log.debug("Registering user: {}", username);
        ResponseEntity<Map> response = restTemplate.postForEntity("/register", Map.of("username", username, "password", password), Map.class);
        assertEquals(HttpStatus.OK, response.getStatusCode(), "Registration failed for " + username);
        return (String) response.getBody().get("accessToken");
    }

    @Test
    void test1_AccountUpdateUsernameSuccess() {
        log.info("Starting Test 1: Update Username Success");
        String token = registerAndGetToken("user1", "password123");
        
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);
        HttpEntity<Map<String, String>> entity = new HttpEntity<>(Map.of("username", "user1updated"), headers);
        
        ResponseEntity<Map> response = restTemplate.exchange("/me", HttpMethod.PUT, entity, Map.class);
        log.debug("Update response status: {}", response.getStatusCode());
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        String newToken = (String) response.getBody().get("accessToken");
        assertNotNull(newToken);

        // Verify with login using new username
        ResponseEntity<Map> loginRes = restTemplate.postForEntity("/login", Map.of("username", "user1updated", "password", "password123"), Map.class);
        assertEquals(HttpStatus.OK, loginRes.getStatusCode(), "Login with updated username failed");
    }

    @Test
    void test2_AccountUpdatePasswordSuccess() {
        log.info("Starting Test 2: Update Password Success");
        String token = registerAndGetToken("user2", "password123");
        
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);
        HttpEntity<Map<String, String>> entity = new HttpEntity<>(Map.of("password", "newpassword456"), headers);
        
        ResponseEntity<Map> response = restTemplate.exchange("/me", HttpMethod.PUT, entity, Map.class);
        assertEquals(HttpStatus.OK, response.getStatusCode());

        ResponseEntity<Map> loginRes = restTemplate.postForEntity("/login", Map.of("username", "user2", "password", "newpassword456"), Map.class);
        assertEquals(HttpStatus.OK, loginRes.getStatusCode(), "Login with new password failed");
    }

    @Test
    void test3_AccountUpdateDuplicateUsername() {
        log.info("Starting Test 3: Update Duplicate Username");
        String tokenA = registerAndGetToken("userA", "password123");
        registerAndGetToken("userB", "password123");
        
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(tokenA);
        HttpEntity<Map<String, String>> entity = new HttpEntity<>(Map.of("username", "userB"), headers);
        
        ResponseEntity<Map> response = restTemplate.exchange("/me", HttpMethod.PUT, entity, Map.class);
        log.debug("Duplicate username response status: {}", response.getStatusCode());
        // Per requirement: RuntimeException results in 500 via CustomErrorController
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    void test4_AccountUpdateValidationErrors() {
        log.info("Starting Test 4: Validation Errors");
        String token = registerAndGetToken("userV", "password123");
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);

        // Short username (< 3)
        ResponseEntity<Map> res1 = restTemplate.exchange("/me", HttpMethod.PUT, new HttpEntity<>(Map.of("username", "ab"), headers), Map.class);
        assertEquals(HttpStatus.BAD_REQUEST, res1.getStatusCode(), "Short username should be 400");

        // Short password (< 6)
        ResponseEntity<Map> res2 = restTemplate.exchange("/me", HttpMethod.PUT, new HttpEntity<>(Map.of("password", "12345"), headers), Map.class);
        assertEquals(HttpStatus.BAD_REQUEST, res2.getStatusCode(), "Short password should be 400");
    }

    @Test
    void test5_AccountUpdateUnauthorized() {
        log.info("Starting Test 5: Unauthorized Access");
        HttpEntity<Map<String, String>> entity = new HttpEntity<>(Map.of("username", "hack"));
        ResponseEntity<Map> response = restTemplate.exchange("/me", HttpMethod.PUT, entity, Map.class);
        log.debug("Unauthorized request response status: {}", response.getStatusCode());
        // Spring Security Config specifies .authenticated() for /me/**
        assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
    }
}