package com.codeplain.messaging.conformance;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = com.codeplain.messaging.MessagingApplication.class)
public class LogoutConformanceTest {

    private static final Logger log = LoggerFactory.getLogger(LogoutConformanceTest.class);

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void testAccountLogoutSuccess() {
        log.info("Starting Test 1: AccountLogoutSuccessTest");
        
        String username = "logoutUser" + System.currentTimeMillis();
        Map<String, String> regRequest = Map.of("username", username, "password", "password123");
        
        log.debug("Registering user: {}", username);
        ResponseEntity<Map> regResponse = restTemplate.postForEntity("/register", regRequest, Map.class);
        assertEquals(HttpStatus.OK, regResponse.getStatusCode(), "Registration should succeed");
        
        String token = (String) regResponse.getBody().get("accessToken");
        assertNotNull(token, "AccessToken should not be null after registration");
        log.debug("User registered. Token obtained: {}...", token.substring(0, 10));

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);
        HttpEntity<Void> entity = new HttpEntity<>(headers);

        log.debug("Sending logout request with valid token");
        ResponseEntity<Void> logoutResponse = restTemplate.postForEntity("/logout", entity, Void.class);

        log.info("Logout response status: {}", logoutResponse.getStatusCode());
        assertEquals(HttpStatus.NO_CONTENT, logoutResponse.getStatusCode(), "Logout should return 204 No Content");
    }

    @Test
    void testAccountLogoutInvalidTokenFormat() {
        log.info("Starting Test 2: AccountLogoutInvalidTokenFormatTest");

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "InvalidFormatTokenWithoutBearer");
        HttpEntity<Void> entity = new HttpEntity<>(headers);

        log.debug("Sending logout request with invalid Authorization header format");
        ResponseEntity<Void> logoutResponse = restTemplate.postForEntity("/logout", entity, Void.class);

        log.info("Logout response status for invalid format: {}", logoutResponse.getStatusCode());
        // Based on implementation, a RuntimeException is thrown when "Bearer " prefix is missing, 
        // resulting in 500 via the CustomErrorController mapping for /error.
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, logoutResponse.getStatusCode(), 
            "Logout with invalid token format should result in 500 Internal Server Error");
    }
}