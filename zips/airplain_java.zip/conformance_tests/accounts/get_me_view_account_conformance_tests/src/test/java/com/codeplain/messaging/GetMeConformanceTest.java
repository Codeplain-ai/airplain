package com.codeplain.messaging;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = MessagingApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class GetMeConformanceTest {
    private static final Logger log = LoggerFactory.getLogger(GetMeConformanceTest.class);

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void test1_AccountGetMeSuccessTest() {
        log.info("Starting Test 1: AccountGetMeSuccessTest");
        String username = "user_" + System.currentTimeMillis();
        String password = "password123";

        log.debug("Registering user: {}", username);
        ResponseEntity<Map> regResp = restTemplate.postForEntity("/register", Map.of("username", username, "password", password), Map.class);
        assertEquals(HttpStatus.OK, regResp.getStatusCode(), "Registration failed");
        String token = (String) regResp.getBody().get("accessToken");

        log.debug("Calling GET /me with token");
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);
        ResponseEntity<Map> meResp = restTemplate.exchange("/me", HttpMethod.GET, new HttpEntity<>(headers), Map.class);

        assertEquals(HttpStatus.OK, meResp.getStatusCode());
        assertEquals(username, meResp.getBody().get("username"), "Username in response does not match registered username");
        log.info("Test 1 completed successfully");
    }

    @Test
    void test2_AccountGetMeUnauthorizedTest() {
        log.info("Starting Test 2: AccountGetMeUnauthorizedTest");
        log.debug("Calling GET /me without Authorization header");
        ResponseEntity<Void> response = restTemplate.getForEntity("/me", Void.class);
        assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode(), "Expected 403 Forbidden for unauthorized access");
        log.info("Test 2 completed successfully");
    }

    @Test
    void test3_AccountGetMeAfterUpdateTest() {
        log.info("Starting Test 3: AccountGetMeAfterUpdateTest");
        String oldUser = "old_" + System.currentTimeMillis();
        String newUser = "new_" + System.currentTimeMillis();

        log.debug("Registering user: {}", oldUser);
        ResponseEntity<Map> regResp = restTemplate.postForEntity("/register", Map.of("username", oldUser, "password", "pass123"), Map.class);
        String token = (String) regResp.getBody().get("accessToken");

        log.debug("Updating username to: {}", newUser);
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);
        ResponseEntity<Map> updateResp = restTemplate.exchange("/me", HttpMethod.PUT, new HttpEntity<>(Map.of("username", newUser), headers), Map.class);
        assertEquals(HttpStatus.OK, updateResp.getStatusCode());
        String newToken = (String) updateResp.getBody().get("accessToken");

        log.debug("Calling GET /me with new token");
        headers.setBearerAuth(newToken);
        ResponseEntity<Map> meResp = restTemplate.exchange("/me", HttpMethod.GET, new HttpEntity<>(headers), Map.class);

        assertEquals(HttpStatus.OK, meResp.getStatusCode());
        assertEquals(newUser, meResp.getBody().get("username"), "Username mismatch after update");
        log.info("Test 3 completed successfully");
    }
}