package com.codeplain.messaging.conformance;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = com.codeplain.messaging.MessagingApplication.class, 
                webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class AccountRegistrationConformanceTest {

    private static final Logger log = LoggerFactory.getLogger(AccountRegistrationConformanceTest.class);

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void test1_HealthCheck() {
        log.info("Executing Test 1: HealthCheckEndpointTest");
        ResponseEntity<Void> response = restTemplate.getForEntity("/healthcheck", Void.class);
        log.info("HealthCheck Response Status: {}", response.getStatusCode());
        assertEquals(HttpStatus.OK, response.getStatusCode(), "HealthCheck should return 200 OK");
    }

    @Test
    void test2_RegistrationSuccess() {
        log.info("Executing Test 2: AccountRegistrationSuccessTest");
        Map<String, String> request = Map.of("username", "user1", "password", "password123");
        ResponseEntity<Map> response = restTemplate.postForEntity("/register", request, Map.class);
        
        log.info("Registration Response: {}", response.getBody());
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody().get("accessToken"), "Response must contain accessToken");
    }

    @Test
    void test3_RegistrationDuplicateUsername() {
        log.info("Executing Test 3: AccountRegistrationDuplicateUsernameTest");
        Map<String, String> request = Map.of("username", "dupUser", "password", "password123");
        
        restTemplate.postForEntity("/register", request, Map.class);
        log.info("First registration attempt finished");

        ResponseEntity<Map> response = restTemplate.postForEntity("/register", request, Map.class);
        log.info("Second registration attempt status: {}", response.getStatusCode());
        
        // Per CustomErrorController, RuntimeException (duplicate) maps to 500
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    void test4_RegistrationValidationErrors() {
        log.info("Executing Test 4: AccountRegistrationValidationErrorTest");

        // Missing username
        ResponseEntity<Map> res1 = restTemplate.postForEntity("/register", Map.of("password", "validPass"), Map.class);
        log.info("Missing username status: {}", res1.getStatusCode());
        assertTrue(res1.getStatusCode().is4xxClientError());

        // Password too short
        ResponseEntity<Map> res2 = restTemplate.postForEntity("/register", 
            Map.of("username", "shorty", "password", "123"), Map.class);
        log.info("Short password status: {}", res2.getStatusCode());
        assertTrue(res2.getStatusCode().is4xxClientError());
    }
}