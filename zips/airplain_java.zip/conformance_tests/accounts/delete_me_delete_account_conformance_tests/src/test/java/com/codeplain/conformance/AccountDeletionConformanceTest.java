package com.codeplain.conformance;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = com.codeplain.messaging.MessagingApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class AccountDeletionConformanceTest {
    private static final Logger log = LoggerFactory.getLogger(AccountDeletionConformanceTest.class);

    @Autowired
    private TestRestTemplate restTemplate;

    private String registerAndGetToken(String user) {
        log.info("Registering user: {}", user);
        Map<String, String> req = Map.of("username", user, "password", "password123");
        ResponseEntity<Map> resp = restTemplate.postForEntity("/register", req, Map.class);
        return (String) resp.getBody().get("accessToken");
    }

    @Test
    void testAccountDeletionSuccess() {
        log.info("Starting Test 1: AccountDeletionSuccessTest");
        String token = registerAndGetToken("testUser1");
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);

        log.info("Sending DELETE /me request");
        ResponseEntity<Void> delResp = restTemplate.exchange("/me", HttpMethod.DELETE, new HttpEntity<>(headers), Void.class);
        assertEquals(HttpStatus.NO_CONTENT, delResp.getStatusCode(), "Expected 204 No Content for deletion");

        log.info("Verifying login fails for deleted account");
        Map<String, String> loginReq = Map.of("username", "testUser1", "password", "password123");
        ResponseEntity<Map> loginResp = restTemplate.postForEntity("/login", loginReq, Map.class);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, loginResp.getStatusCode(), "Expected 500 for missing account login");
    }

    @Test
    void testAccountDeletionUnauthorized() {
        log.info("Starting Test 2: AccountDeletionUnauthorizedTest");
        ResponseEntity<Void> resp = restTemplate.exchange("/me", HttpMethod.DELETE, HttpEntity.EMPTY, Void.class);
        assertEquals(HttpStatus.FORBIDDEN, resp.getStatusCode(), "Expected 403 Forbidden without token");
    }

    @Test
    void testAccountDeletionAfterLogout() {
        log.info("Starting Test 3: AccountDeletionAfterLogoutTest");
        String token = registerAndGetToken("testUser3");
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);

        log.info("Logging out to blacklist token");
        restTemplate.exchange("/logout", HttpMethod.POST, new HttpEntity<>(headers), Void.class);

        log.info("Attempting DELETE /me with blacklisted token");
        ResponseEntity<Void> resp = restTemplate.exchange("/me", HttpMethod.DELETE, new HttpEntity<>(headers), Void.class);
        assertNotEquals(HttpStatus.NO_CONTENT, resp.getStatusCode(), "Should not allow deletion with blacklisted token");
    }
}