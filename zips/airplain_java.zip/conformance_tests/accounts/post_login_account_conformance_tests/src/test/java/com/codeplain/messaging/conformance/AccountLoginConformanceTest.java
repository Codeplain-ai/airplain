package com.codeplain.messaging.conformance;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = com.codeplain.messaging.MessagingApplication.class)
public class AccountLoginConformanceTest {

    private static final Logger log = LoggerFactory.getLogger(AccountLoginConformanceTest.class);

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void test1_AccountLoginSuccess() {
        log.info("Starting Test 1: AccountLoginSuccessTest");
        String username = "testUser1";
        String password = "password123";

        log.debug("Registering user: {}", username);
        restTemplate.postForEntity("/register", Map.of("username", username, "password", password), Map.class);

        log.debug("Sending login request for user: {}", username);
        ResponseEntity<Map> response = restTemplate.postForEntity("/login", 
            Map.of("username", username, "password", password), Map.class);

        log.info("Login Response Status: {}", response.getStatusCode());
        assertEquals(HttpStatus.OK, response.getStatusCode(), "Expected 200 OK for valid credentials");
        assertNotNull(response.getBody().get("accessToken"), "Access token should not be null");
        assertFalse(response.getBody().get("accessToken").toString().isEmpty(), "Access token should not be empty");
    }

    @Test
    void test2_AccountLoginInvalidCredentials() {
        log.info("Starting Test 2: AccountLoginInvalidCredentialsTest");
        String username = "testUser2";
        String correctPass = "password123";
        String wrongPass = "wrongPassword";

        log.debug("Registering user: {}", username);
        restTemplate.postForEntity("/register", Map.of("username", username, "password", correctPass), Map.class);

        log.debug("Attempting login with incorrect password");
        ResponseEntity<Map> wrongPassResp = restTemplate.postForEntity("/login", 
            Map.of("username", username, "password", wrongPass), Map.class);
        log.info("Wrong Password Response Status: {}", wrongPassResp.getStatusCode());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, wrongPassResp.getStatusCode(), "Expected 500 for wrong password");

        log.debug("Attempting login with non-existent user");
        ResponseEntity<Map> nonExistentResp = restTemplate.postForEntity("/login", 
            Map.of("username", "ghostUser", "password", "anyPass"), Map.class);
        log.info("Non-existent User Response Status: {}", nonExistentResp.getStatusCode());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, nonExistentResp.getStatusCode(), "Expected 500 for non-existent user");
    }

    @Test
    void test3_AccountLoginValidation() {
        log.info("Starting Test 3: AccountLoginValidationTest");

        log.debug("Attempting login with empty username");
        ResponseEntity<Map> emptyUserResp = restTemplate.postForEntity("/login", 
            Map.of("username", "", "password", "password123"), Map.class);
        log.info("Empty Username Response Status: {}", emptyUserResp.getStatusCode());
        assertEquals(HttpStatus.BAD_REQUEST, emptyUserResp.getStatusCode(), "Expected 400 for empty username");

        log.debug("Attempting login with null password");
        ResponseEntity<Map> nullPassResp = restTemplate.postForEntity("/login", 
            Map.of("username", "testUser3", "password", ""), Map.class);
        log.info("Empty Password Response Status: {}", nullPassResp.getStatusCode());
        assertEquals(HttpStatus.BAD_REQUEST, nullPassResp.getStatusCode(), "Expected 400 for empty password");
    }
}