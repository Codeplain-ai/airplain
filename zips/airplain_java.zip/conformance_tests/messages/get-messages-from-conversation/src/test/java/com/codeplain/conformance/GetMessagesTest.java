package com.codeplain.conformance;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import com.codeplain.messaging.MessagingApplication;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = MessagingApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class GetMessagesTest {
    private static final Logger log = LoggerFactory.getLogger(GetMessagesTest.class);

    @Autowired
    private TestRestTemplate restTemplate;

    private String register(String user) {
        Map<String, String> req = Map.of("username", user, "password", "password123");
        ResponseEntity<Map> res = restTemplate.postForEntity("/register", req, Map.class);
        return (String) res.getBody().get("accessToken");
    }

    private HttpHeaders headers(String token) {
        HttpHeaders h = new HttpHeaders();
        h.setBearerAuth(token);
        return h;
    }

    @Test
    void testGetMessagesSuccessful() {
        log.info("Starting GetMessagesSuccessful");
        String tokenA = register("UserA");
        register("UserB");
        
        Map<String, String> msgReq = Map.of("recipientUsername", "UserB", "content", "Hello B");
        ResponseEntity<Map> sendRes = restTemplate.exchange("/messages", HttpMethod.POST, new HttpEntity<>(msgReq, headers(tokenA)), Map.class);
        
        // To get the conversation ID, we need to find it from the database or assume 1L for the first entry in a clean H2.
        // Given the requirement to only use basic file I/O and no external apps, we rely on the sequential ID generation.
        Long convId = 1L;
        log.info("Attempting to fetch messages for conversation ID: {}", convId);

        ResponseEntity<List> getRes = restTemplate.exchange("/messages/" + convId, HttpMethod.GET, new HttpEntity<>(headers(tokenA)), List.class);
        assertEquals(HttpStatus.OK, getRes.getStatusCode());
        assertFalse(getRes.getBody().isEmpty());
        log.info("GetMessagesSuccessful passed");
    }

    @Test
    void testGetMessagesUnauthorized() {
        log.info("Starting GetMessagesUnauthorized");
        ResponseEntity<Void> res = restTemplate.getForEntity("/messages/1", Void.class);
        assertEquals(HttpStatus.FORBIDDEN, res.getStatusCode());
    }

    @Test
    void testGetMessagesConversationNotFound() {
        log.info("Starting GetMessagesConversationNotFound");
        String token = register("UserC");
        ResponseEntity<Void> res = restTemplate.exchange("/messages/9999", HttpMethod.GET, new HttpEntity<>(headers(token)), Void.class);
        assertEquals(HttpStatus.NOT_FOUND, res.getStatusCode());
    }

    @Test
    void testGetMessagesForbiddenForNonParticipant() {
        log.info("Starting GetMessagesForbiddenForNonParticipant");
        String tokenA = register("UserD");
        register("UserE");
        String tokenC = register("UserF");

        Map<String, String> msgReq = Map.of("recipientUsername", "UserE", "content", "Private");
        restTemplate.exchange("/messages", HttpMethod.POST, new HttpEntity<>(msgReq, headers(tokenA)), Map.class);

        ResponseEntity<Void> res = restTemplate.exchange("/messages/1", HttpMethod.GET, new HttpEntity<>(headers(tokenC)), Void.class);
        assertEquals(HttpStatus.FORBIDDEN, res.getStatusCode());
    }
}