package com.codeplain.tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.util.Map;
import java.util.UUID;

import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.DEFINED_PORT;

@SpringBootTest(classes = com.codeplain.messaging.MessagingApplication.class, webEnvironment = DEFINED_PORT)
public class SendMessageConformanceTest {
    private static final Logger log = LoggerFactory.getLogger(SendMessageConformanceTest.class);

    @Autowired
    private WebTestClient webTestClient;

    private String getAuthToken(String username) {
        log.info("Registering user: {}", username);
        return webTestClient.post().uri("/register")
                .bodyValue(Map.of("username", username, "password", "password123"))
                .exchange()
                .expectStatus().isOk()
                .returnResult(Map.class)
                .getResponseBody().blockFirst()
                .get("accessToken").toString();
    }

    @Test
    void testSendMessageSuccessful() {
        String u1 = "user_" + UUID.randomUUID();
        String u2 = "user_" + UUID.randomUUID();
        String token = getAuthToken(u1);
        getAuthToken(u2);

        log.info("Test 1: Sending message from {} to {}", u1, u2);
        webTestClient.post().uri("/messages")
                .header("Authorization", "Bearer " + token)
                .bodyValue(Map.of("recipientUsername", u2, "content", "Hello!"))
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.id").exists()
                .jsonPath("$.senderUsername").isEqualTo(u1)
                .jsonPath("$.content").isEqualTo("Hello!")
                .jsonPath("$.timestamp").exists();
    }

    @Test
    void testSendMessageUnauthorized() {
        log.info("Test 2: Sending message without token");
        webTestClient.post().uri("/messages")
                .bodyValue(Map.of("recipientUsername", "any", "content", "Hi"))
                .exchange()
                .expectStatus().isForbidden();
    }

    @Test
    void testSendMessageRecipientNotFound() {
        String token = getAuthToken("sender_" + UUID.randomUUID());
        log.info("Test 3: Sending message to non-existent user");
        webTestClient.post().uri("/messages")
                .header("Authorization", "Bearer " + token)
                .bodyValue(Map.of("recipientUsername", "nonexistent_user", "content", "Hi"))
                .exchange()
                .expectStatus().isNotFound();
    }

    @Test
    void testSendMessageToSelfForbidden() {
        String user = "self_" + UUID.randomUUID();
        String token = getAuthToken(user);
        log.info("Test 4: User {} sending message to self", user);
        webTestClient.post().uri("/messages")
                .header("Authorization", "Bearer " + token)
                .bodyValue(Map.of("recipientUsername", user, "content", "Hi"))
                .exchange()
                .expectStatus().isBadRequest();
    }

    @Test
    void testSendMessageValidationError() {
        String token = getAuthToken("validator_" + UUID.randomUUID());
        log.info("Test 5: Validation errors (empty content)");
        webTestClient.post().uri("/messages")
                .header("Authorization", "Bearer " + token)
                .bodyValue(Map.of("recipientUsername", "any", "content", ""))
                .exchange()
                .expectStatus().isBadRequest();
    }
}