package com.codeplain.messaging;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class GetConversationsConformanceTest {
    private static final Logger log = LoggerFactory.getLogger(GetConversationsConformanceTest.class);

    @Autowired
    private TestRestTemplate restTemplate;

    private String register(String username, String password) {
        Map<String, String> req = Map.of("username", username, "password", password);
        ResponseEntity<Map> res = restTemplate.postForEntity("/register", req, Map.class);
        return (String) res.getBody().get("accessToken");
    }

    private void sendMessage(String token, String to, String msg) {
        HttpHeaders h = new HttpHeaders();
        h.setBearerAuth(token);
        restTemplate.postForEntity("/messages", new HttpEntity<>(Map.of("recipientUsername", to, "content", msg), h), Map.class);
    }

    @Test
    void testGetConversationsSuccessful() {
        log.info("Starting testGetConversationsSuccessful");
        String t1 = register("user1", "pass123");
        String t2 = register("user2", "pass123");
        register("user3", "pass123");

        sendMessage(t1, "user2", "Hello U2");
        sendMessage(t1, "user3", "Hello U3");

        HttpHeaders h1 = new HttpHeaders();
        h1.setBearerAuth(t1);
        ResponseEntity<List> r1 = restTemplate.exchange("/messages/conversations", HttpMethod.GET, new HttpEntity<>(h1), List.class);
        
        assertEquals(HttpStatus.OK, r1.getStatusCode());
        assertEquals(2, r1.getBody().size(), "User1 should have 2 conversations");

        HttpHeaders h2 = new HttpHeaders();
        h2.setBearerAuth(t2);
        ResponseEntity<List> r2 = restTemplate.exchange("/messages/conversations", HttpMethod.GET, new HttpEntity<>(h2), List.class);
        assertEquals(1, r2.getBody().size(), "User2 should have 1 conversation");
    }

    @Test
    void testGetConversationsUnauthorized() {
        log.info("Starting testGetConversationsUnauthorized");
        ResponseEntity<Void> res = restTemplate.getForEntity("/messages/conversations", Void.class);
        assertEquals(HttpStatus.FORBIDDEN, res.getStatusCode());
    }

    @Test
    void testGetConversationsEmptyList() {
        log.info("Starting testGetConversationsEmptyList");
        String token = register("emptyUser", "pass123");
        HttpHeaders h = new HttpHeaders();
        h.setBearerAuth(token);
        ResponseEntity<List> res = restTemplate.exchange("/messages/conversations", HttpMethod.GET, new HttpEntity<>(h), List.class);
        assertEquals(HttpStatus.OK, res.getStatusCode());
        assertTrue(res.getBody().isEmpty(), "New user should have no conversations");
    }

    @Test
    void testGetConversationsWithInvalidToken() {
        log.info("Starting testGetConversationsWithInvalidToken");
        HttpHeaders h = new HttpHeaders();
        h.set("Authorization", "Bearer malformed.token.here");
        ResponseEntity<Void> res = restTemplate.exchange("/messages/conversations", HttpMethod.GET, new HttpEntity<>(h), Void.class);
        assertEquals(HttpStatus.FORBIDDEN, res.getStatusCode());
    }
}