package com.codeplain.messaging.dto;

import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Builder
public class MessageResponse {
    private Long id;
    private String senderUsername;
    private String content;
    private LocalDateTime timestamp;
}