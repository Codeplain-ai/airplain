package com.codeplain.messaging.service;

import com.codeplain.messaging.dto.AccountResponse;
import com.codeplain.messaging.dto.AuthResponse;
import com.codeplain.messaging.dto.LoginRequest;
import com.codeplain.messaging.dto.RegistrationRequest;
import com.codeplain.messaging.dto.UpdateAccountRequest;
import com.codeplain.messaging.model.Account;
import com.codeplain.messaging.model.BlacklistedToken;
import com.codeplain.messaging.repository.AccountRepository;
import com.codeplain.messaging.repository.BlacklistedTokenRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class AccountService {

    private final AccountRepository accountRepository;
    private final BlacklistedTokenRepository blacklistedTokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    @Transactional
    public AuthResponse register(RegistrationRequest request) {
        log.debug("Attempting to register user: {}", request.getUsername());

        if (accountRepository.findByUsername(request.getUsername()).isPresent()) {
            log.warn("Registration failed: Username {} already exists", request.getUsername());
            throw new RuntimeException("Username already exists");
        }

        Account account = Account.builder()
                .username(request.getUsername())
                .password(passwordEncoder.encode(request.getPassword()))
                .build();

        accountRepository.save(account);
        log.debug("User {} registered successfully", request.getUsername());

        String token = jwtService.generateToken(account.getUsername());
        return AuthResponse.builder()
                .accessToken(token)
                .build();
    }

    @Transactional(readOnly = true)
    public AuthResponse login(LoginRequest request) {
        log.debug("Attempting to login user: {}", request.getUsername());

        Account account = accountRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> {
                    log.warn("Login failed: User {} not found", request.getUsername());
                    return new RuntimeException("Invalid username or password");
                });

        if (!passwordEncoder.matches(request.getPassword(), account.getPassword())) {
            log.warn("Login failed: Incorrect password for user {}", request.getUsername());
            throw new RuntimeException("Invalid username or password");
        }

        log.debug("User {} logged in successfully", request.getUsername());
        String token = jwtService.generateToken(account.getUsername());
        return AuthResponse.builder()
                .accessToken(token)
                .build();
    }

    @Transactional
    public void logout(String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            log.warn("Logout failed: Invalid Authorization header");
            throw new RuntimeException("Invalid token format for logout");
        }

        String token = authHeader.substring(7);
        log.debug("Attempting to logout/blacklist token");

        if (blacklistedTokenRepository.existsById(token)) {
            log.debug("Token already blacklisted");
            return;
        }

        BlacklistedToken blacklistedToken = BlacklistedToken.builder()
                .token(token)
                .expiryDate(jwtService.getExpirationDate(token))
                .build();

        blacklistedTokenRepository.save(blacklistedToken);
        log.debug("Token successfully blacklisted");
    }

    @Transactional(readOnly = true)
    public AccountResponse getMe() {
        String currentUsername = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        log.debug("Fetching account details for user: {}", currentUsername);

        Account account = accountRepository.findByUsername(currentUsername)
                .orElseThrow(() -> {
                    log.error("Fetch failed: Account not found for username {}", currentUsername);
                    return new RuntimeException("Account not found");
                });

        return AccountResponse.builder()
                .username(account.getUsername())
                .build();
    }

    @Transactional
    public AuthResponse updateMe(UpdateAccountRequest request) {
        String currentUsername = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        log.debug("Attempting to update account for user: {}", currentUsername);

        Account account = accountRepository.findByUsername(currentUsername)
                .orElseThrow(() -> {
                    log.error("Update failed: Account not found for username {}", currentUsername);
                    return new RuntimeException("Account not found");
                });

        if (request.getUsername() != null && !request.getUsername().equals(account.getUsername())) {
            if (accountRepository.findByUsername(request.getUsername()).isPresent()) {
                log.warn("Update failed: New username {} already exists", request.getUsername());
                throw new RuntimeException("Username already exists");
            }
            account.setUsername(request.getUsername());
        }

        if (request.getPassword() != null) {
            account.setPassword(passwordEncoder.encode(request.getPassword()));
        }

        accountRepository.save(account);
        log.debug("Account for user {} updated successfully", currentUsername);

        String newToken = jwtService.generateToken(account.getUsername());
        return AuthResponse.builder()
                .accessToken(newToken)
                .build();
    }

    @Transactional
    public void deleteMe() {
        String currentUsername = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        log.debug("Attempting to delete account for user: {}", currentUsername);

        Account account = accountRepository.findByUsername(currentUsername)
                .orElseThrow(() -> {
                    log.error("Delete failed: Account not found for username {}", currentUsername);
                    return new RuntimeException("Account not found for deletion");
                });

        accountRepository.delete(account);
        log.debug("Account for user {} deleted successfully", currentUsername);
    }
}