package com.codeplain.messaging.controller;

import com.codeplain.messaging.dto.AccountResponse;
import com.codeplain.messaging.dto.AuthResponse;
import com.codeplain.messaging.dto.LoginRequest;
import com.codeplain.messaging.dto.RegistrationRequest;
import com.codeplain.messaging.dto.UpdateAccountRequest;
import com.codeplain.messaging.service.AccountService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class AccountController {

    private final AccountService accountService;

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegistrationRequest request) {
        return ResponseEntity.ok(accountService.register(request));
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest request) {
        return ResponseEntity.ok(accountService.login(request));
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logout(@RequestHeader("Authorization") String authHeader) {
        accountService.logout(authHeader);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/me")
    public ResponseEntity<AccountResponse> getMe() {
        return ResponseEntity.ok(accountService.getMe());
    }

    @PutMapping("/me")
    public ResponseEntity<AuthResponse> updateMe(@Valid @RequestBody UpdateAccountRequest request) {
        return ResponseEntity.ok(accountService.updateMe(request));
    }

    @DeleteMapping("/me")
    public ResponseEntity<Void> deleteMe() {
        accountService.deleteMe();
        return ResponseEntity.noContent().build();
    }
}