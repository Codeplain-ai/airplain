package com.codeplain.messaging.service;

import com.codeplain.messaging.dto.ConversationResponse;
import com.codeplain.messaging.dto.MessageResponse;
import com.codeplain.messaging.dto.SendMessageRequest;
import com.codeplain.messaging.model.Account;
import com.codeplain.messaging.model.Conversation;
import com.codeplain.messaging.model.Message;
import com.codeplain.messaging.repository.AccountRepository;
import com.codeplain.messaging.repository.ConversationRepository;
import com.codeplain.messaging.repository.MessageRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MessageService {
    private final MessageRepository messageRepository;
    private final ConversationRepository conversationRepository;
    private final AccountRepository accountRepository;

    public MessageResponse sendMessage(String senderUsername, SendMessageRequest request) {
        Account sender = accountRepository.findByUsername(senderUsername)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Sender not found"));
        
        Account recipient = accountRepository.findByUsername(request.getRecipientUsername())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Recipient not found"));

        if (sender.equals(recipient)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Cannot send message to self");
        }

        Conversation conversation = conversationRepository.findBetweenUsers(sender, recipient)
                .orElseGet(() -> conversationRepository.save(
                        Conversation.builder().user1(sender).user2(recipient).build()
                ));

        Message message = Message.builder()
                .sender(sender)
                .conversation(conversation)
                .content(request.getContent())
                .build();

        Message saved = messageRepository.save(message);

        return MessageResponse.builder()
                .id(saved.getId())
                .senderUsername(sender.getUsername())
                .content(saved.getContent())
                .timestamp(saved.getTimestamp())
                .build();
    }

    public List<MessageResponse> getMessages(Long conversationId, String username) {
        Conversation conversation = conversationRepository.findById(conversationId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, 
                    String.format("Conversation with ID %d not found", conversationId)));

        Account account = accountRepository.findByUsername(username)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, 
                    String.format("Account with username %s not found", username)));

        if (!conversation.getUser1().equals(account) && !conversation.getUser2().equals(account)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, 
                "User is not a participant of this conversation");
        }

        return conversation.getMessages().stream()
                .map(msg -> MessageResponse.builder()
                        .id(msg.getId())
                        .senderUsername(msg.getSender().getUsername())
                        .content(msg.getContent())
                        .timestamp(msg.getTimestamp())
                        .build())
                .collect(Collectors.toList());
    }

    public List<ConversationResponse> getConversations(String username) {
        Account account = accountRepository.findByUsername(username)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        String.format("User with username '%s' not found for conversation retrieval", username)));

        return conversationRepository.findAllByParticipant(account).stream()
                .map(conv -> ConversationResponse.builder()
                        .id(conv.getId())
                        .user1Username(conv.getUser1().getUsername())
                        .user2Username(conv.getUser2().getUsername())
                        .build())
                .collect(Collectors.toList());
    }
}