import unittest
import subprocess
import time
import urllib.request
import urllib.error
import logging
import sys
import os
import signal

# Configure logging to stdout for visibility in test logs
logging.basicConfig(level=logging.DEBUG, stream=sys.stdout)
logger = logging.getLogger(__name__)

class TestHealthcheckConformance(unittest.TestCase):
    """
    Conformance tests for the healthcheck functionality.
    Verifies that the App provides a /healthcheck endpoint returning 200 OK.
    """
    
    @classmethod
    def setUpClass(cls):
        """Start the App server as a background process."""
        logger.info("Starting the App server for conformance testing...")
        
        # Determine the path to app.py relative to the build folder structure
        # The run script copies app.py to the root of the build folder
        cls.server_process = subprocess.Popen(
            [sys.executable, "app.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            preexec_fn=os.setsid if os.name != 'nt' else None
        )
        
        cls.base_url = "http://127.0.0.1:6000"
        cls.health_url = f"{cls.base_url}/healthcheck"
        
        # Wait for server to become ready
        max_retries = 10
        retry_delay = 0.5
        for i in range(max_retries):
            try:
                logger.debug(f"Waiting for server readiness (attempt {i+1})...")
                with urllib.request.urlopen(cls.health_url, timeout=1) as response:
                    if response.getcode() == 200:
                        logger.info("Server is up and running.")
                        return
            except (urllib.error.URLError, ConnectionResetError):
                time.sleep(retry_delay)
        
        cls.tearDownClass()
        raise RuntimeError("Failed to start the App server within the timeout period.")

    @classmethod
    def tearDownClass(cls):
        """Shutdown the App server."""
        if hasattr(cls, 'server_process'):
            logger.info("Terminating the App server...")
            if os.name != 'nt':
                try:
                    os.killpg(os.getpgid(cls.server_process.pid), signal.SIGTERM)
                except Exception as e:
                    logger.error(f"Error killing process group: {e}")
            else:
                cls.server_process.terminate()
            cls.server_process.wait()
            logger.info("App server terminated.")

    def test_healthcheck_endpoint(self):
        """
        Verify that a GET request to /healthcheck returns 200 OK.
        """
        logger.info(f"Sending GET request to {self.health_url}")
        
        try:
            with urllib.request.urlopen(self.health_url, timeout=2) as response:
                status_code = response.getcode()
                logger.debug(f"Response status code: {status_code}")
                
                self.assertEqual(
                    status_code, 
                    200, 
                    f"Expected status code 200, but received {status_code}."
                )
            
            logger.info("Healthcheck endpoint validation successful.")
            
        except urllib.error.HTTPError as e:
            self.assertEqual(e.code, 200, f"Expected status code 200, but received {e.code}")
        except Exception as e:
            self.fail(f"Request to /healthcheck failed with exception: {e}")

if __name__ == '__main__':
    unittest.main()