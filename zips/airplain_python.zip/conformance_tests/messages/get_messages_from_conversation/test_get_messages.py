import unittest
import urllib.request
import urllib.error
import time
import subprocess
import os
import logging
import json

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class TestGetMessages(unittest.TestCase):
    PORT = "6000"
    BASE_URL = f"http://127.0.0.1:{PORT}"
    server_process = None

    @classmethod
    def setUpClass(cls):
        logging.info("Starting the application server for conformance testing...")
        env = os.environ.copy()
        env["PORT"] = cls.PORT
        cls.server_process = subprocess.Popen(
            ["python3", "app.py"],
            env=env
        )
        
        # Wait for the server to be ready
        success = False
        for i in range(20):
            if cls.server_process.poll() is not None:
                raise RuntimeError("Server process exited prematurely.")
            try:
                with urllib.request.urlopen(f"{cls.BASE_URL}/healthcheck", timeout=1) as response:
                    if response.status == 200:
                        logging.info("Server is up and running.")
                        success = True
                        break
            except Exception:
                pass
            time.sleep(0.5)
        
        if not success:
            raise RuntimeError("Server failed to start in time.")

    @classmethod
    def tearDownClass(cls):
        if cls.server_process:
            logging.info("Shutting down the application server.")
            cls.server_process.terminate()
            cls.server_process.wait()

    def _make_request(self, path, method="GET", data=None, headers=None):
        url = f"{self.BASE_URL}{path}"
        req_headers = headers.copy() if headers else {}
        body = None
        
        if data:
            body = json.dumps(data).encode('utf-8')
            req_headers["Content-Type"] = "application/json"
        
        req = urllib.request.Request(url, data=body, headers=req_headers, method=method)
        try:
            with urllib.request.urlopen(req) as response:
                resp_data = response.read().decode('utf-8')
                return response.status, json.loads(resp_data) if resp_data else None
        except urllib.error.HTTPError as e:
            resp_data = e.read().decode('utf-8')
            try:
                return e.code, json.loads(resp_data) if resp_data else None
            except:
                return e.code, None
        except Exception as e:
            logging.error(f"Request failed: {e}")
            return None, None

    def _register_and_login(self, username, password):
        logging.info(f"Registering and logging in user: {username}")
        self._make_request("/register", method="POST", data={"username": username, "password": password})
        status, data = self._make_request("/login", method="POST", data={"username": username, "password": password})
        return data.get("access_token") if data else None

    def test_get_messages_success(self):
        logging.info("Executing test_get_messages_success")
        token_a = self._register_and_login("userA", "passA")
        self._register_and_login("userB", "passB")
        
        headers_a = {"Authorization": f"Bearer {token_a}"}
        content = "Hello B, this is A"
        status, data = self._make_request("/messages", method="POST", 
                                         data={"recipient_username": "userB", "content": content}, 
                                         headers=headers_a)
        self.assertEqual(status, 201)
        
        # We need to find the conversation ID. Since it's not returned by POST /messages,
        # and tests share the DB, we iterate to find the one we just created.
        found = False
        for conv_id in range(1, 50):
            status, messages = self._make_request(f"/messages/{conv_id}", headers=headers_a)
            if status == 200:
                # Check if this conversation contains our message
                if any(m['content'] == content for m in messages):
                    logging.info(f"Found conversation ID: {conv_id}")
                    self.assertEqual(messages[0]['sender_username'], "userA")
                    found = True
                    break
        
        self.assertTrue(found, "Could not find the created conversation")

    def test_get_messages_unauthorized(self):
        logging.info("Executing test_get_messages_unauthorized")
        # Attempt to access a likely conversation ID without token
        status, _ = self._make_request("/messages/1")
        self.assertEqual(status, 401, "Should fail without token")

    def test_get_messages_forbidden_access(self):
        logging.info("Executing test_get_messages_forbidden_access")
        token_a = self._register_and_login("userA_f", "pass")
        self._register_and_login("userB_f", "pass")
        token_c = self._register_and_login("userC_f", "pass")
        
        headers_a = {"Authorization": f"Bearer {token_a}"}
        # Create a conversation
        self._make_request("/messages", method="POST", data={"recipient_username": "userB_f", "content": "hi"}, headers=headers_a)
        
        # User C attempts access. We iterate through a few IDs to find the one created.
        headers_c = {"Authorization": f"Bearer {token_c}"}
        forbidden_found = False
        for cid in range(1, 10):
            status, _ = self._make_request(f"/messages/{cid}", headers=headers_c)
            if status == 403:
                forbidden_found = True
                break
        self.assertTrue(forbidden_found, "User C should encounter a 403 for a conversation they aren't in")

    def test_get_messages_not_found(self):
        logging.info("Executing test_get_messages_not_found")
        token = self._register_and_login("user_nf", "pass")
        headers = {"Authorization": f"Bearer {token}"}
        status, _ = self._make_request("/messages/99999", headers=headers)
        self.assertEqual(status, 404)

    def test_get_messages_chronological_order(self):
        logging.info("Executing test_get_messages_chronological_order")
        token_a = self._register_and_login("userA_ord", "pass")
        self._register_and_login("userB_ord", "pass")
        headers = {"Authorization": f"Bearer {token_a}"}
        
        contents = ["First", "Second", "Third"]
        for msg in contents:
            self._make_request("/messages", method="POST", data={"recipient_username": "userB_ord", "content": msg}, headers=headers)
            time.sleep(0.1)
            
        found = False
        for cid in range(1, 20):
            status, messages = self._make_request(f"/messages/{cid}", headers=headers)
            if status == 200:
                received_contents = [m['content'] for m in messages if m['content'] in contents]
                if len(received_contents) == 3:
                    self.assertEqual(received_contents, contents, "Messages should be in chronological order")
                    found = True
                    break
        self.assertTrue(found, "Could not find the conversation for order verification")

if __name__ == "__main__":
    unittest.main()