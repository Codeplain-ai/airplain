import unittest
import time
import subprocess
import os
import logging
import json
import urllib.request
import urllib.error

# Configure logging for the tests
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class TestGetConversations(unittest.TestCase):
    BASE_URL = "http://127.0.0.1:6001"
    server_process = None

    @classmethod
    def setUpClass(cls):
        """Start the App server once for all tests in this class."""
        logger.info("Starting the App server...")
        env = os.environ.copy()
        env['PORT'] = '6001'
        
        cls.server_process = subprocess.Popen(
            ['python3', 'app.py'],
            env=env
        )
        
        # Wait for the server to be ready
        for i in range(20):
            if cls.server_process.poll() is not None:
                raise RuntimeError("Server process exited prematurely.")
            try:
                with urllib.request.urlopen(f"{cls.BASE_URL}/healthcheck", timeout=1) as response:
                    if response.status == 200:
                        logger.info("Server is up and running.")
                        return
            except Exception:
                pass
            time.sleep(0.5)
        raise RuntimeError("Server failed to start")

    @classmethod
    def tearDownClass(cls):
        """Terminate the server process."""
        if cls.server_process:
            logger.info("Terminating the App server...")
            cls.server_process.terminate()
            try:
                cls.server_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                cls.server_process.kill()

    def _make_request(self, path, method='GET', data=None, headers=None):
        """Helper to make HTTP requests using urllib."""
        url = f"{self.BASE_URL}{path}"
        req_headers = headers or {}
        
        json_data = None
        if data is not None:
            json_data = json.dumps(data).encode('utf-8')
            req_headers['Content-Type'] = 'application/json'
            
        req = urllib.request.Request(url, data=json_data, headers=req_headers, method=method)
        
        try:
            with urllib.request.urlopen(req) as response:
                res_data = response.read().decode('utf-8')
                return response.status, json.loads(res_data) if res_data else None
        except urllib.error.HTTPError as e:
            res_data = e.read().decode('utf-8')
            return e.code, json.loads(res_data) if res_data else None
        except Exception as e:
            logger.error(f"Request failed: {e}")
            return None, None

    def _register_and_login(self, username, password):
        """Helper to create a user and get an access token."""
        logger.debug(f"Registering user: {username}")
        reg_payload = {"username": username, "password": password}
        self._make_request("/register", method='POST', data=reg_payload)
        
        logger.debug(f"Logging in user: {username}")
        status, body = self._make_request("/login", method='POST', data=reg_payload)
        return body.get("access_token") if body else None

    def test_get_conversations_success(self):
        """Test 1: Verify UserA sees conversations with UserB and UserC."""
        logger.info("Executing test_get_conversations_success")
        token_a = self._register_and_login("UserA", "passA")
        self._register_and_login("UserB", "passB")
        self._register_and_login("UserC", "passC")

        headers_a = {"Authorization": f"Bearer {token_a}"}
        
        # UserA sends message to B
        logger.debug("UserA sending message to UserB")
        self._make_request("/messages", method='POST', headers=headers_a, 
                           data={"recipient_username": "UserB", "content": "Hi B"})
        
        # UserA sends message to C
        logger.debug("UserA sending message to UserC")
        self._make_request("/messages", method='POST', headers=headers_a, 
                           data={"recipient_username": "UserC", "content": "Hi C"})

        status, data = self._make_request("/conversations", headers=headers_a)
        self.assertEqual(status, 200)
        self.assertEqual(len(data), 2, f"Expected 2 conversations, got {len(data)}")
        
        participants = []
        for conv in data:
            participants.extend([conv['participant1_username'], conv['participant2_username']])
        
        self.assertIn("UserB", participants)
        self.assertIn("UserC", participants)
        logger.info("test_get_conversations_success passed")

    def test_get_conversations_unauthorized(self):
        """Test 2: Verify 401 when no token is provided."""
        logger.info("Executing test_get_conversations_unauthorized")
        status, _ = self._make_request("/conversations")
        self.assertEqual(status, 401)
        logger.info("test_get_conversations_unauthorized passed")

    def test_get_conversations_empty_list(self):
        """Test 3: Verify new user has empty conversation list."""
        logger.info("Executing test_get_conversations_empty_list")
        token = self._register_and_login("LonelyUser", "pass")
        headers = {"Authorization": f"Bearer {token}"}
        
        status, data = self._make_request("/conversations", headers=headers)
        self.assertEqual(status, 200)
        self.assertEqual(data, [])
        logger.info("test_get_conversations_empty_list passed")

    def test_get_conversations_isolated_participants(self):
        """Test 4: Verify UserA does not see conversations between UserC and UserD."""
        logger.info("Executing test_get_conversations_isolated_participants")
        token_a = self._register_and_login("IsoA", "pass")
        self._register_and_login("IsoB", "pass")
        token_c = self._register_and_login("IsoC", "pass")
        self._register_and_login("IsoD", "pass")

        # C sends message to D
        logger.debug("IsoC sending message to IsoD")
        self._make_request("/messages", method='POST', headers={"Authorization": f"Bearer {token_c}"}, 
                           data={"recipient_username": "IsoD", "content": "Secret"})

        # A checks conversations
        status, data = self._make_request("/conversations", headers={"Authorization": f"Bearer {token_a}"})
        self.assertEqual(status, 200)
        for conv in data:
            self.assertNotIn("IsoC", [conv['participant1_username'], conv['participant2_username']])
            self.assertNotIn("IsoD", [conv['participant1_username'], conv['participant2_username']])
        logger.info("test_get_conversations_isolated_participants passed")

if __name__ == '__main__':
    unittest.main()