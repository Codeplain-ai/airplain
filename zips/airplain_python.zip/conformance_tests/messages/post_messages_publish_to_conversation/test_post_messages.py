import unittest
import urllib.request
import urllib.error
import json
import time
import subprocess
import os
import logging

# Configure logging for tests
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class TestPostMessages(unittest.TestCase):
    BASE_URL = "http://127.0.0.1:6001"
    server_process = None

    @classmethod
    def setUpClass(cls):
        """Start the Flask application server."""
        logger.info("Starting the application server for conformance tests...")
        env = os.environ.copy()
        env['PORT'] = '6001'
        cls.server_process = subprocess.Popen(
            ["python3", "app.py"],
            env=env
        )
        
        timeout = 5
        start_time = time.time()
        while time.time() - start_time < timeout:
            if cls.server_process.poll() is not None:
                raise RuntimeError("Server process exited prematurely.")
            try:
                with urllib.request.urlopen(f"{cls.BASE_URL}/healthcheck") as response:
                    if response.status == 200:
                        logger.info("Server is up and running.")
                        return
            except urllib.error.URLError:
                time.sleep(0.2)
        
        cls.tearDownClass()
        raise RuntimeError("Server failed to start within timeout.")

    @classmethod
    def tearDownClass(cls):
        """Terminate the application server."""
        if cls.server_process:
            logger.info("Terminating the application server...")
            cls.server_process.terminate()
            cls.server_process.wait()

    def _make_request(self, path, method='GET', data=None, headers=None):
        """Helper to perform HTTP requests using urllib."""
        url = f"{self.BASE_URL}{path}"
        req_headers = {'Content-Type': 'application/json'}
        if headers:
            req_headers.update(headers)
        
        json_data = json.dumps(data).encode('utf-8') if data else None
        req = urllib.request.Request(url, data=json_data, headers=req_headers, method=method)
        
        try:
            with urllib.request.urlopen(req) as response:
                return response.status, json.loads(response.read().decode('utf-8'))
        except urllib.error.HTTPError as e:
            body = e.read().decode('utf-8')
            try:
                return e.code, json.loads(body)
            except:
                return e.code, body
        except urllib.error.URLError as e:
            logger.error(f"URL Error: {e.reason}")
            raise

    def _register_and_login(self, username, password):
        """Helper to create a user and get an access token."""
        payload = {"username": username, "password": password}
        self._make_request("/register", "POST", data=payload)
        status, data = self._make_request("/login", "POST", data=payload)
        return data.get("access_token")

    def test_post_message_success(self):
        """Test 1: Successfully send a message between two users."""
        logger.info("Running: test_post_message_success")
        token_a = self._register_and_login("userA", "passA")
        self._register_and_login("userB", "passB")
        
        headers = {"Authorization": f"Bearer {token_a}"}
        payload = {"recipient_username": "userB", "content": "Hello userB!"}
        
        status, data = self._make_request("/messages", "POST", data=payload, headers=headers)
        self.assertEqual(status, 201, f"Expected 201, got {status}: {data}")
        
        self.assertIn("id", data)
        self.assertEqual(data["sender_username"], "userA")
        self.assertEqual(data["recipient_username"], "userB")
        self.assertEqual(data["content"], "Hello userB!")
        self.assertIn("timestamp", data)

    def test_post_message_unauthorized(self):
        """Test 2: Send message without Authorization header."""
        logger.info("Running: test_post_message_unauthorized")
        payload = {"recipient_username": "any", "content": "hi"}
        # _make_request uses default empty headers
        status, data = self._make_request("/messages", "POST", data=payload)
        self.assertEqual(status, 401, "Expected 401 for unauthorized request")

    def test_post_message_recipient_not_found(self):
        """Test 3: Send message to a non-existent user."""
        logger.info("Running: test_post_message_recipient_not_found")
        token = self._register_and_login("sender1", "pass1")
        headers = {"Authorization": f"Bearer {token}"}
        payload = {"recipient_username": "ghost_user", "content": "Are you there?"}
        
        status, data = self._make_request("/messages", "POST", data=payload, headers=headers)
        self.assertEqual(status, 404, "Expected 404 for non-existent recipient")

    def test_post_message_invalid_payload(self):
        """Test 4: Send message with invalid JSON payload."""
        logger.info("Running: test_post_message_invalid_payload")
        token = self._register_and_login("sender2", "pass2")
        headers = {"Authorization": f"Bearer {token}"}
        # Missing 'content' field
        payload = {"recipient_username": "userA"}
        
        status, data = self._make_request("/messages", "POST", data=payload, headers=headers)
        self.assertEqual(status, 400, "Expected 400 for invalid payload")

    def test_post_message_to_self_forbidden(self):
        """Test 5: Sending a message to oneself should be forbidden/bad request."""
        logger.info("Running: test_post_message_to_self_forbidden")
        token = self._register_and_login("self_user", "pass")
        headers = {"Authorization": f"Bearer {token}"}
        payload = {"recipient_username": "self_user", "content": "Note to self"}
        
        status, data = self._make_request("/messages", "POST", data=payload, headers=headers)
        self.assertEqual(status, 400, "Expected 400 for sending message to self")

if __name__ == "__main__":
    unittest.main()