import unittest
import subprocess
import time
import json
import urllib.request
import urllib.error
import logging
import sys
import os
import socket

# Configure logging to stdout for visibility
logging.basicConfig(level=logging.DEBUG, stream=sys.stdout)
logger = logging.getLogger(__name__)

class TestRegisterAccountConformance(unittest.TestCase):
    PORT = 6001
    BASE_URL = f"http://127.0.0.1:{PORT}"
    process = None

    @classmethod
    def setUpClass(cls):
        """Start the App server on a specific port before running tests."""
        logger.info("Starting the App server for conformance testing...")
        
        # Ensure the port is free
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(('127.0.0.1', cls.PORT)) == 0:
                logger.warning(f"Port {cls.PORT} is already in use.")

        # Start the application as a subprocess
        # We assume app.py is in the current working directory as per the test runner script
        env = os.environ.copy()
        env["PORT"] = str(cls.PORT)
        logger.debug(f"Launching app with PORT={cls.PORT}")

        # Ensure Flask runs on our specific port
        cls.process = subprocess.Popen(
            [sys.executable, "app.py"],
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        # Wait for the server to be ready
        timeout = 5
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                with urllib.request.urlopen(f"{cls.BASE_URL}/healthcheck", timeout=1) as response:
                    if response.getcode() == 200:
                        logger.info("Server is up and running.")
                        return
            except Exception:
                time.sleep(0.2)
        
        logger.error("Server failed to start within timeout.")
        cls.tearDownClass()
        raise RuntimeError("Could not connect to the App server.")

    @classmethod
    def tearDownClass(cls):
        """Terminate the App server after all tests."""
        if cls.process:
            logger.info("Terminating the App server...")
            cls.process.terminate()
            cls.process.wait()

    def test_register_account_success(self):
        """Test 1: test_register_account_success - Verify valid registration."""
        endpoint = f"{self.BASE_URL}/register"
        payload = {
            "username": "testuser",
            "password": "securepassword123",
            "email": "test@example.com"
        }
        data = json.dumps(payload).encode('utf-8')
        
        logger.info(f"Sending POST to {endpoint} with payload: {payload}")
        try:
            req = urllib.request.Request(endpoint, data=data, headers={'Content-Type': 'application/json'}, method='POST')
            with urllib.request.urlopen(req) as response:
                status_code = response.getcode()
                body = response.read().decode('utf-8')
                logger.debug(f"Response Status: {status_code}")
                logger.debug(f"Response Body: {body}")
                
                # Check for 200 OK or 201 Created
                self.assertIn(status_code, [200, 201], 
                              f"Expected 200 or 201, got {status_code}. Body: {body}")
        except urllib.error.HTTPError as e:
            logger.error(f"Request failed with status {e.code}: {e.read().decode('utf-8')}")
            raise
        except Exception as e:
            logger.error(f"Request failed: {e}")
            raise

    def test_register_account_invalid_payload(self):
        """Test 2: test_register_account_invalid_payload - Verify error handling for bad input."""
        endpoint = f"{self.BASE_URL}/register"
        payload = {"invalid": "data"}
        data = json.dumps(payload).encode('utf-8')
        
        logger.info(f"Sending invalid POST to {endpoint} with payload: {payload}")
        try:
            req = urllib.request.Request(endpoint, data=data, headers={'Content-Type': 'application/json'}, method='POST')
            with urllib.request.urlopen(req) as response:
                status_code = response.getcode()
                logger.debug(f"Response Status: {status_code}")
                self.assertTrue(400 <= status_code < 500)
        except urllib.error.HTTPError as e:
            logger.debug(f"Response Status: {e.code}")
            # Verify it's a client error (4xx) and not a server error (500)
            self.assertTrue(400 <= e.code < 500, 
                            f"Expected 4xx client error, got {e.code}")
            self.assertNotEqual(e.code, 500, "Server returned 500 Internal Server Error")
        except Exception as e:
            logger.error(f"Request failed: {e}")
            raise

if __name__ == "__main__":
    unittest.main()