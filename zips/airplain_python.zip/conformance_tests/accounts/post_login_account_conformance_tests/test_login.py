import unittest
import urllib.request
import urllib.error
import json
import time
import subprocess
import os
import signal
import logging
import sys

# Configure logging for the conformance tests
logging.basicConfig(level=logging.DEBUG, stream=sys.stdout)
logger = logging.getLogger("ConformanceTests")

class TestLoginAccountConformance(unittest.TestCase):
    BASE_URL = "http://127.0.0.1:6001"
    server_process = None

    @classmethod
    def setUpClass(cls):
        """Start the App server before running tests."""
        logger.info("Starting the App server for login conformance tests...")
        env = os.environ.copy()
        env["PORT"] = "6001"
        # Run app.py as a subprocess. We assume app.py is in the current working directory.
        # We redirect stdout/stderr to sys.stdout/sys.stderr to avoid pipe buffering issues 
        # and to see server logs in the test output.
        cls.server_process = subprocess.Popen(
            [sys.executable, "app.py"],
            env=env
        )
        # Give the server a moment to start
        time.sleep(2.0)
        
        # Check if the process is still running
        if cls.server_process.poll() is not None:
            logger.error("Server process failed to start or crashed immediately.")
            stdout, stderr = cls.server_process.communicate()
            logger.error(f"STDOUT: {stdout}")
            logger.error(f"STDERR: {stderr}")
            raise RuntimeError("App server failed to start.")

        logger.info(f"Server started with PID: {cls.server_process.pid}")

    @classmethod
    def tearDownClass(cls):
        """Stop the App server after all tests are finished."""
        if cls.server_process:
            logger.info("Terminating the App server...")
            cls.server_process.terminate()
            cls.server_process.wait()
            logger.info("Server terminated.")

    def _post(self, url, data):
        req = urllib.request.Request(
            url, 
            data=json.dumps(data).encode('utf-8'), 
            headers={'Content-Type': 'application/json'},
            method='POST'
        )
        try:
            with urllib.request.urlopen(req) as response:
                return response.getcode(), json.loads(response.read().decode('utf-8'))
        except urllib.error.HTTPError as e:
            try:
                error_body = e.read().decode('utf-8')
                return e.code, json.loads(error_body) if error_body else {}
            except:
                return e.code, {}
        except Exception as e:
            logger.error(f"Request failed: {e}")
            raise

    def test_login_success(self):
        """Test 1: Register a user and login successfully."""
        username = "testuser_success"
        password = "testpassword123"
        
        # Registration
        logger.debug(f"Registering user: {username}")
        reg_payload = {"username": username, "password": password}
        status, data = self._post(f"{self.BASE_URL}/register", reg_payload)
        self.assertEqual(status, 201, f"Registration failed: {data}")

        # Login
        logger.debug(f"Attempting login for user: {username}")
        login_payload = {"username": username, "password": password}
        status, data = self._post(f"{self.BASE_URL}/login", login_payload)
        
        self.assertEqual(status, 200, f"Login failed: {data}")
        self.assertEqual(data.get("username"), username)
        self.assertIn("access_token", data)
        self.assertTrue(len(data["access_token"]) > 0)
        logger.info("test_login_success passed.")

    def test_login_invalid_credentials(self):
        """Test 2: Login with wrong password or non-existent user."""
        username = "testuser_invalid"
        password = "correct_password"
        
        # Register
        self._post(f"{self.BASE_URL}/register", {"username": username, "password": password})

        # Wrong password
        logger.debug("Attempting login with incorrect password")
        status, _ = self._post(f"{self.BASE_URL}/login", {"username": username, "password": "wrong"})
        self.assertEqual(status, 401, "Expected 401 for wrong password")

        # Non-existent user
        logger.debug("Attempting login for non-existent user")
        status, _ = self._post(f"{self.BASE_URL}/login", {"username": "ghost", "password": "any"})
        self.assertEqual(status, 401, "Expected 401 for non-existent user")
        logger.info("test_login_invalid_credentials passed.")

    def test_login_missing_fields(self):
        """Test 3: Login with missing payload fields."""
        logger.debug("Attempting login with missing password field")
        status_missing, _ = self._post(f"{self.BASE_URL}/login", {"username": "user"})
        self.assertEqual(status_missing, 400, "Expected 400 for missing password")

        logger.debug("Attempting login with empty object")
        status_empty, _ = self._post(f"{self.BASE_URL}/login", {})
        self.assertEqual(status_empty, 400, "Expected 400 for empty payload")
        
        self.assertNotEqual(status_missing, 500, "Server returned 500 on validation error")
        logger.info("test_login_missing_fields passed.")

if __name__ == "__main__":
    unittest.main()