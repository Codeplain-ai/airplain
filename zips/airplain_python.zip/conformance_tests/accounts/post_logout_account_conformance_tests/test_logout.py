import unittest
import urllib.request
import urllib.error
import time
import subprocess
import sys
import os
import logging

# Configure logging for conformance tests
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class TestLogoutConformance(unittest.TestCase):
    """
    Conformance tests for the POST /logout endpoint.
    These tests interact with the application as a black box over HTTP.
    """
    server_process = None
    base_url = "http://127.0.0.1:6001"

    @classmethod
    def setUpClass(cls):
        """Start the App server before running tests."""
        logger.info("Starting the application server for conformance tests...")
        env = os.environ.copy()
        env['PORT'] = '6001'
        
        # Start the app.py process without pipes to avoid deadlocks
        cls.server_process = subprocess.Popen(
            [sys.executable, "app.py"],
            env=env
        )
        
        # Wait for the server to be ready using the healthcheck endpoint
        max_retries = 20
        url = f"{cls.base_url}/healthcheck"
        for i in range(max_retries):
            try:
                with urllib.request.urlopen(url, timeout=1) as response:
                    if response.getcode() == 200:
                        logger.info("Server is up and running.")
                        return
            except (urllib.error.URLError, ConnectionResetError):
                pass
            
            if cls.server_process.poll() is not None:
                raise RuntimeError("Server process terminated unexpectedly.")
                
            logger.debug(f"Waiting for server... ({i+1}/{max_retries})")
            time.sleep(0.2)
        
        cls.tearDownClass()
        raise RuntimeError("Failed to start the application server.")

    @classmethod
    def tearDownClass(cls):
        """Shutdown the App server after tests."""
        if cls.server_process:
            logger.info("Terminating the application server...")
            cls.server_process.terminate()
            cls.server_process.wait()

    def test_logout_success(self):
        """
        Validates that the /logout endpoint is accessible and returns a 200 OK status code.
        """
        endpoint = f"{self.base_url}/logout"
        logger.info(f"Testing POST request to {endpoint}")
        
        try:
            # Use urllib to perform POST request
            req = urllib.request.Request(endpoint, method='POST')
            with urllib.request.urlopen(req, timeout=2) as response:
                status_code = response.getcode()
                logger.debug(f"Response Status Code: {status_code}")
                
                # Validation
                self.assertEqual(
                    status_code, 
                    200, 
                    f"Expected status code 200 for /logout, but got {status_code}."
                )
            logger.info("test_logout_success passed.")
            
        except urllib.error.HTTPError as e:
            self.assertEqual(
                e.code, 
                200, 
                f"Expected status code 200 for /logout, but got {e.code}."
            )
        except Exception as e:
            self.fail(f"Request to /logout failed: {e}")

if __name__ == '__main__':
    unittest.main()