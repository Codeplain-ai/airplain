import unittest
import urllib.request
import urllib.error
import json
import time
import subprocess
import logging
import os
import sys

# Configure logging for the tests
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class TestPutMeAccount(unittest.TestCase):
    PORT = 6001
    BASE_URL = f"http://127.0.0.1:{PORT}"
    process = None

    @classmethod
    def setUpClass(cls):
        """Start the Flask application as a subprocess."""
        logger.info("Starting the Flask application for conformance tests...")
        env = os.environ.copy()
        env['PORT'] = str(cls.PORT)
        
        cls.process = subprocess.Popen(
            [sys.executable, "app.py"],
            env=env,
            stdout=None,
            stderr=None
        )
        
        # Wait for the server to start
        timeout = 5.0
        start_time = time.time()
        while time.time() - start_time < timeout:
            if cls.process.poll() is not None:
                raise RuntimeError("Server process exited prematurely.")
            try:
                # Use healthcheck to verify server is up
                with urllib.request.urlopen(f"{cls.BASE_URL}/healthcheck", timeout=1) as response:
                    if response.status == 200:
                        logger.info("Server is up and running.")
                        return
            except Exception:
                pass
            time.sleep(0.2)
        
        cls.tearDownClass()
        raise RuntimeError("Server failed to start within timeout.")

    @classmethod
    def tearDownClass(cls):
        if cls.process:
            logger.info("Terminating the Flask application...")
            cls.process.terminate()
            cls.process.wait()

    def _make_request(self, path, method='GET', data=None, headers=None):
        url = f"{self.BASE_URL}{path}"
        headers = headers or {}
        if data is not None and 'Content-Type' not in headers:
            headers['Content-Type'] = 'application/json'
        
        json_data = json.dumps(data).encode('utf-8') if data is not None else None
        req = urllib.request.Request(url, data=json_data, headers=headers, method=method)
        
        try:
            with urllib.request.urlopen(req) as response:
                return response.status, json.loads(response.read().decode('utf-8'))
        except urllib.error.HTTPError as e:
            try:
                body = json.loads(e.read().decode('utf-8'))
            except Exception:
                body = None
            return e.code, body
        except Exception as e:
            logger.error(f"Request failed: {e}")
            return 500, None

    def register_and_login(self, username, password):
        """Helper to create an account and get a token."""
        logger.debug(f"Registering user: {username}")
        status, _ = self._make_request("/register", method="POST", data={"username": username, "password": password})
        self.assertIn(status, [201, 400], f"Registration failed for {username}")
        
        logger.debug(f"Logging in user: {username}")
        status, body = self._make_request("/login", method="POST", data={"username": username, "password": password})
        self.assertEqual(status, 200, f"Login failed for {username}")
        return body.get("access_token")

    def test_update_me_success(self):
        """Test 1: Verify authenticated user can update account details."""
        logger.info("Running test_update_me_success")
        token = self.register_and_login("user1", "pass1")
        headers = {"Authorization": f"Bearer {token}"}
        
        update_data = {"username": "user1_new", "password": "pass1_new"}
        logger.debug(f"Sending PUT /me with data: {update_data}")
        status, body = self._make_request("/me", method="PUT", data=update_data, headers=headers)
        
        self.assertEqual(status, 200, f"Expected 200, got {status}. Body: {body}")
        self.assertEqual(body.get("username"), "user1_new")
        
        # Verify new credentials work
        login_status, _ = self._make_request("/login", method="POST", data=update_data)
        self.assertEqual(login_status, 200, "Login with new credentials failed")

    def test_update_me_unauthorized(self):
        """Test 2: Verify /me endpoint is protected."""
        logger.info("Running test_update_me_unauthorized")
        update_data = {"username": "hacker"}
        
        logger.debug("Sending PUT /me without token")
        status, _ = self._make_request("/me", method="PUT", data=update_data)
        self.assertEqual(status, 401, "Expected 401 for missing token")
        
        logger.debug("Sending PUT /me with invalid token")
        headers = {"Authorization": "Bearer invalid_token"}
        status_invalid, _ = self._make_request("/me", method="PUT", data=update_data, headers=headers)
        self.assertEqual(status_invalid, 401, "Expected 401 for invalid token")

    def test_update_me_duplicate_username(self):
        """Test 3: Verify user cannot change username to one already taken."""
        logger.info("Running test_update_me_duplicate_username")
        token_a = self.register_and_login("userA", "passA")
        self.register_and_login("userB", "passB")
        
        headers = {"Authorization": f"Bearer {token_a}"}
        update_data = {"username": "userB"}
        
        logger.debug("Attempting to change userA's username to userB")
        status, _ = self._make_request("/me", method="PUT", data=update_data, headers=headers)
        self.assertEqual(status, 400, "Expected 400 when updating to a duplicate username")

    def test_update_me_partial_update(self):
        """Test 4: Verify partial updates (password only)."""
        logger.info("Running test_update_me_partial_update")
        username = "user_partial"
        token = self.register_and_login(username, "old_pass")
        
        headers = {"Authorization": f"Bearer {token}"}
        update_data = {"password": "new_pass"}
        
        logger.debug(f"Sending partial update for {username}")
        status, body = self._make_request("/me", method="PUT", data=update_data, headers=headers)
        
        self.assertEqual(status, 200)
        self.assertEqual(body.get("username"), username)
        
        # Verify login with new password and old username
        login_status, _ = self._make_request("/login", method="POST", data={"username": username, "password": "new_pass"})
        self.assertEqual(login_status, 200, "Partial update failed to persist password change")

if __name__ == '__main__':
    unittest.main()