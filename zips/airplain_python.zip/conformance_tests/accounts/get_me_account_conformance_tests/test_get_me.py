import unittest
import urllib.request
import urllib.error
import json
import time
import subprocess
import os
import signal
import logging

# Configure logging for the conformance tests
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class TestGetMeConformance(unittest.TestCase):
    BASE_URL = "http://127.0.0.1:6000"
    PROCESS = None

    @classmethod
    def setUpClass(cls):
        """Start the App server and wait for it to be healthy."""
        logger.info("Starting the application server...")
        env = os.environ.copy()
        env["PORT"] = "6000"
        
        # Start the application as a subprocess
        cls.PROCESS = subprocess.Popen(
            ["python3", "app.py"],
            env=env,
            preexec_fn=os.setsid
        )

        # Wait for the healthcheck to return 200
        max_retries = 20
        for i in range(max_retries):
            if cls.PROCESS.poll() is not None:
                raise RuntimeError("Server process exited prematurely.")
            try:
                with urllib.request.urlopen(f"{cls.BASE_URL}/healthcheck", timeout=1) as response:
                    if response.status == 200:
                        logger.info("Server is healthy and ready for tests.")
                        return
            except (urllib.error.URLError, ConnectionError):
                pass
            logger.debug(f"Waiting for server... retry {i+1}/{max_retries}")
            time.sleep(0.5)
        
        cls.tearDownClass()
        raise RuntimeError("Server failed to start in time.")

    @classmethod
    def tearDownClass(cls):
        """Terminate the application server."""
        if cls.PROCESS:
            logger.info("Terminating the application server...")
            try:
                os.killpg(os.getpgid(cls.PROCESS.pid), signal.SIGTERM)
            except Exception as e:
                logger.error(f"Error terminating server: {e}")

    def test_get_me_success(self):
        """
        Test 1: test_get_me_success
        Verifies that a valid token returns the user's account information.
        """
        username = "testuser_get_me"
        password = "testpassword123"
        
        logger.info("Registering a new user...")
        reg_data = json.dumps({"username": username, "password": password}).encode('utf-8')
        req = urllib.request.Request(
            f"{self.BASE_URL}/register",
            data=reg_data,
            headers={'Content-Type': 'application/json'},
            method='POST'
        )
        with urllib.request.urlopen(req) as resp:
            self.assertEqual(resp.status, 201)

        logger.info("Logging in to obtain AccessToken...")
        login_data = json.dumps({"username": username, "password": password}).encode('utf-8')
        req = urllib.request.Request(
            f"{self.BASE_URL}/login",
            data=login_data,
            headers={'Content-Type': 'application/json'},
            method='POST'
        )
        with urllib.request.urlopen(req) as resp:
            self.assertEqual(resp.status, 200)
            data = json.loads(resp.read().decode('utf-8'))
        
        token = data.get("access_token")
        self.assertIsNotNone(token, "AccessToken missing in login response")

        logger.info("Performing GET /me with valid token...")
        req = urllib.request.Request(
            f"{self.BASE_URL}/me",
            headers={"Authorization": f"Bearer {token}"},
            method='GET'
        )
        with urllib.request.urlopen(req) as resp:
            self.assertEqual(resp.status, 200)
            me_data = json.loads(resp.read().decode('utf-8'))
        
        self.assertEqual(me_data.get("username"), username, "Username mismatch in /me response")
        logger.info("test_get_me_success passed.")

    def test_get_me_unauthorized(self):
        """
        Test 2: test_get_me_unauthorized
        Verifies that missing or invalid tokens return 401.
        """
        logger.info("Performing GET /me without Authorization header...")
        req = urllib.request.Request(f"{self.BASE_URL}/me", method='GET')
        try:
            urllib.request.urlopen(req)
            self.fail("Expected 401 for missing token")
        except urllib.error.HTTPError as e:
            self.assertEqual(e.code, 401, "Expected 401 for missing token")

        logger.info("Performing GET /me with malformed Bearer token...")
        req = urllib.request.Request(
            f"{self.BASE_URL}/me",
            headers={"Authorization": "Bearer invalid_token_here"},
            method='GET'
        )
        try:
            urllib.request.urlopen(req)
            self.fail("Expected 401 for invalid token")
        except urllib.error.HTTPError as e:
            self.assertEqual(e.code, 401, "Expected 401 for invalid token")
        logger.info("test_get_me_unauthorized passed.")

if __name__ == "__main__":
    unittest.main()