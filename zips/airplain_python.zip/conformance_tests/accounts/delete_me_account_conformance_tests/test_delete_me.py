import unittest
import subprocess
import time
import json
import logging
import sys
import os
import urllib.request
import urllib.error

# --- Logging Configuration ---
logging.basicConfig(level=logging.INFO, stream=sys.stdout, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class TestDeleteMe(unittest.TestCase):
    PORT = 6001
    BASE_URL = f"http://127.0.0.1:{PORT}"

    @classmethod
    def setUpClass(cls):
        """Starts the Flask app in a background process."""
        logger.info(f"Starting Flask application on port {cls.PORT}...")
        env = os.environ.copy()
        env['PORT'] = str(cls.PORT)
        # Use sys.executable to ensure we use the same python as the test runner
        cls.server_process = subprocess.Popen(
            [sys.executable, "app.py"],
            env=env,
            stdout=None,
            stderr=None
        )
        
        # Wait for the server to be ready
        timeout = 5
        start_time = time.time()
        while time.time() - start_time < timeout:
            if cls.server_process.poll() is not None:
                raise RuntimeError("Server process exited prematurely.")
            try:
                with urllib.request.urlopen(f"{cls.BASE_URL}/healthcheck", timeout=1) as response:
                    if response.getcode() == 200:
                        logger.info("Server is up and running.")
                        return
            except Exception:
                pass
            time.sleep(0.2)
        raise RuntimeError("Server failed to start within timeout.")

    @classmethod
    def tearDownClass(cls):
        """Terminates the Flask app process."""
        if hasattr(cls, 'server_process'):
            logger.info("Terminating server process...")
            cls.server_process.terminate()
            cls.server_process.wait()

    def _make_request(self, path, method='GET', json_data=None, headers=None):
        url = f"{self.BASE_URL}{path}"
        logger.info(f"Request: {method} {url}")
        
        data = None
        if json_data:
            data = json.dumps(json_data).encode('utf-8')
        
        req_headers = {'Content-Type': 'application/json'}
        if headers:
            req_headers.update(headers)
            
        req = urllib.request.Request(url, data=data, headers=req_headers, method=method)
        
        try:
            with urllib.request.urlopen(req, timeout=5) as response:
                status_code = response.getcode()
                body = response.read().decode('utf-8')
                logger.info(f"Response: {status_code}")
                return status_code, json.loads(body) if body else {}
        except urllib.error.HTTPError as e:
            status_code = e.code
            body = e.read().decode('utf-8')
            logger.info(f"HTTP Error: {status_code}")
            return status_code, json.loads(body) if body else {}
        except urllib.error.URLError as e:
            logger.error(f"URL Error: {e.reason}")
            raise

    def test_delete_me_success(self):
        """Verifies that a user can successfully delete their account."""
        username = "testuser_delete"
        password = "testpassword123"

        # 1. Register account
        logger.info(f"Step 1: Registering account for {username}")
        reg_payload = {"username": username, "password": password}
        status, data = self._make_request("/register", method='POST', json_data=reg_payload)
        self.assertEqual(status, 201, "Registration failed")
        token = data.get("access_token")
        self.assertIsNotNone(token, "No access token received after registration")

        # 2. Delete account
        logger.info(f"Step 2: Deleting account for {username}")
        headers = {"Authorization": f"Bearer {token}"}
        status, _ = self._make_request("/me", method='DELETE', headers=headers)
        self.assertEqual(status, 204, f"Delete account failed: {status}")

        # 3. Verify deletion by attempting login
        logger.info("Step 3: Verifying deletion by attempting login")
        status, _ = self._make_request("/login", method='POST', json_data=reg_payload)
        self.assertEqual(status, 401, "Login should fail for deleted account")

        # 4. Verify deletion by viewing profile
        logger.info("Step 4: Verifying deletion by attempting to GET /me with old token")
        status, _ = self._make_request("/me", method='GET', headers=headers)
        self.assertEqual(status, 401, "GET /me should fail with old token for deleted account")

    def test_delete_me_unauthorized(self):
        """Ensures that the DELETE /me endpoint is protected by authentication."""
        # Scenario 1: No Authorization header
        logger.info("Testing DELETE /me without Authorization header")
        status, _ = self._make_request("/me", method='DELETE')
        self.assertEqual(status, 401, "Expected 401 for missing auth header")

        # Scenario 2: Invalid Bearer token
        logger.info("Testing DELETE /me with invalid Bearer token")
        headers = {"Authorization": "Bearer invalid_token_string"}
        status, _ = self._make_request("/me", method='DELETE', headers=headers)
        self.assertEqual(status, 401, "Expected 401 for invalid bearer token")

if __name__ == "__main__":
    unittest.main()