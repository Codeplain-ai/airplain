import logging
import json
from flask import Blueprint, Response, request
from pydantic import ValidationError

from models import (
    db, Account, Conversation, Message, 
    MessageCreateSchema, MessageResponseSchema,
    ConversationResponseSchema
)
def setup_logging():
    """
    Configures the logging for the application.
    Sets root logger to DEBUG and others to WARNING.
    """
    import logging
    import sys
    logging.basicConfig(level=logging.DEBUG, stream=sys.stdout)
    for logger_name in logging.root.manager.loggerDict:
        logging.getLogger(logger_name).setLevel(logging.WARNING)

from utils import get_authenticated_user

messaging_api = Blueprint('messaging_api', __name__)

@messaging_api.route('/messages', methods=['POST'])
def send_message():
    logging.debug("Send message endpoint called")
    sender = get_authenticated_user()
    if not sender:
        return Response(status=401)

    try:
        data = request.get_json()
        if not data:
            return Response(status=400)

        msg_data = MessageCreateSchema(**data)
        recipient = Account.query.filter_by(username=msg_data.recipient_username).first()
        
        if not recipient:
            return Response(status=404, response="Recipient not found")

        if sender.id == recipient.id:
            return Response(status=400, response="Cannot send message to self")

        a1, a2 = sorted([sender.id, recipient.id])
        conv = Conversation.query.filter_by(account1_id=a1, account2_id=a2).first()
        
        if not conv:
            conv = Conversation(account1_id=a1, account2_id=a2)
            db.session.add(conv)
            db.session.flush()

        new_msg = Message(
            conversation_id=conv.id,
            sender_id=sender.id,
            content=msg_data.content
        )
        db.session.add(new_msg)
        db.session.commit()

        response_data = MessageResponseSchema(
            id=new_msg.id,
            sender_username=sender.username,
            recipient_username=recipient.username,
            content=new_msg.content,
            timestamp=str(new_msg.timestamp)
        )
        
        return Response(
            response_data.model_dump_json(),
            status=201,
            mimetype='application/json'
        )
    except ValidationError as e:
        logging.warning(f"Validation error: {e}")
        return Response(status=400)
    except Exception as e:
        logging.error(f"Message send error: {e}", exc_info=True)
        db.session.rollback()
        return Response(status=500)

@messaging_api.route('/conversations', methods=['GET'])
def get_conversations():
    logging.debug("Get conversations endpoint called")
    user = get_authenticated_user()
    if not user:
        return Response(status=401)

    try:
        conversations = Conversation.query.filter(
            (Conversation.account1_id == user.id) | (Conversation.account2_id == user.id)
        ).all()

        results = []
        for conv in conversations:
            acc1 = Account.query.get(conv.account1_id)
            acc2 = Account.query.get(conv.account2_id)
            
            res_schema = ConversationResponseSchema(
                id=conv.id,
                participant1_username=acc1.username if acc1 else "Unknown",
                participant2_username=acc2.username if acc2 else "Unknown"
            )
            results.append(res_schema.model_dump())

        return Response(
            json.dumps(results),
            status=200,
            mimetype='application/json'
        )
    except Exception as e:
        logging.error(f"Error fetching conversations: {e}", exc_info=True)
        return Response(status=500)

@messaging_api.route('/messages/<int:conversationId>', methods=['GET'])
def get_messages(conversationId):
    logging.debug(f"Get messages for conversation {conversationId} called")
    user = get_authenticated_user()
    if not user:
        return Response(status=401)

    try:
        conv = Conversation.query.get(conversationId)
        if not conv:
            return Response(status=404)

        if user.id != conv.account1_id and user.id != conv.account2_id:
            logging.warning(f"User {user.username} unauthorized access attempt to conversation {conversationId}")
            return Response(status=403)

        messages = Message.query.filter_by(conversation_id=conversationId).order_by(Message.timestamp.asc()).all()
        
        acc1 = Account.query.get(conv.account1_id)
        acc2 = Account.query.get(conv.account2_id)
        id_to_name = {acc1.id: acc1.username, acc2.id: acc2.username}

        results = []
        for msg in messages:
            recipient_id = conv.account2_id if msg.sender_id == conv.account1_id else conv.account1_id
            
            res_schema = MessageResponseSchema(
                id=msg.id,
                sender_username=id_to_name.get(msg.sender_id),
                recipient_username=id_to_name.get(recipient_id),
                content=msg.content,
                timestamp=str(msg.timestamp)
            )
            results.append(res_schema.model_dump())

        return Response(
            json.dumps(results),
            status=200,
            mimetype='application/json'
        )
    except Exception as e:
        logging.error(f"Error fetching messages: {e}", exc_info=True)
        return Response(status=500)