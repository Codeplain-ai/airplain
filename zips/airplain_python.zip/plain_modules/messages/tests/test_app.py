import unittest
import json
import sys
import os

# Add the parent directory to sys.path to allow importing app
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app

class TestApp(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True

    def test_healthcheck_success(self):
        """Test that /healthcheck returns 200 OK."""
        response = self.app.get('/healthcheck')
        self.assertEqual(response.status_code, 200)

    def test_unknown_endpoint_returns_404_empty_body(self):
        """Test that unknown endpoints return 404 and empty body."""
        response = self.app.get('/invalid-route-12345')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.data, b"")

    def test_login_success(self):
        """Test successful login."""
        # First register
        self.app.post('/register', 
                      data=json.dumps({"username": "testuser", "password": "password123"}),
                      content_type='application/json')
        
        # Then login
        response = self.app.post('/login',
                                 data=json.dumps({"username": "testuser", "password": "password123"}),
                                 content_type='application/json')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['username'], 'testuser')
        self.assertIn('access_token', data)

    def test_login_failure_invalid_credentials(self):
        """Test login with wrong password."""
        self.app.post('/register', 
                      data=json.dumps({"username": "user2", "password": "password123"}),
                      content_type='application/json')
        
        response = self.app.post('/login',
                                 data=json.dumps({"username": "user2", "password": "wrongpassword"}),
                                 content_type='application/json')
        self.assertEqual(response.status_code, 401)

    def test_logout_success(self):
        """Test successful logout."""
        response = self.app.post('/logout')
        self.assertEqual(response.status_code, 200)

    def test_update_account_success(self):
        """Test updating account details."""
        # Register and login to get token
        self.app.post('/register', 
                      data=json.dumps({"username": "updateuser", "password": "oldpassword"}),
                      content_type='application/json')
        login_res = self.app.post('/login',
                                  data=json.dumps({"username": "updateuser", "password": "oldpassword"}),
                                  content_type='application/json')
        token = json.loads(login_res.data)['access_token']

        # Update username
        response = self.app.put('/me',
                                data=json.dumps({"username": "newusername"}),
                                headers={"Authorization": f"Bearer {token}"},
                                content_type='application/json')
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['username'], 'newusername')

    def test_update_account_unauthorized(self):
        """Test updating account without token."""
        response = self.app.put('/me',
                                data=json.dumps({"username": "hacker"}),
                                content_type='application/json')
        self.assertEqual(response.status_code, 401)

    def test_view_account_success(self):
        """Test viewing account details."""
        # Register and login
        username = "viewuser"
        self.app.post('/register', 
                      data=json.dumps({"username": username, "password": "password123"}),
                      content_type='application/json')
        login_res = self.app.post('/login',
                                  data=json.dumps({"username": username, "password": "password123"}),
                                  content_type='application/json')
        token = json.loads(login_res.data)['access_token']

        # View account
        response = self.app.get('/me',
                                headers={"Authorization": f"Bearer {token}"})
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['username'], username)

    def test_view_account_unauthorized(self):
        """Test viewing account without token."""
        response = self.app.get('/me')
        self.assertEqual(response.status_code, 401)

    def test_delete_account_success(self):
        """Test successful account deletion."""
        # Register and login
        username = "deleteuser"
        self.app.post('/register', 
                      data=json.dumps({"username": username, "password": "password123"}),
                      content_type='application/json')
        login_res = self.app.post('/login',
                                  data=json.dumps({"username": username, "password": "password123"}),
                                  content_type='application/json')
        token = json.loads(login_res.data)['access_token']

        # Delete account
        response = self.app.delete('/me',
                                   headers={"Authorization": f"Bearer {token}"})
        self.assertEqual(response.status_code, 204)

        # Verify account is gone (login should fail)
        login_fail = self.app.post('/login',
                                   data=json.dumps({"username": username, "password": "password123"}),
                                   content_type='application/json')
        self.assertEqual(login_fail.status_code, 401)

    def test_delete_account_unauthorized(self):
        """Test deleting account without token."""
        response = self.app.delete('/me')
        self.assertEqual(response.status_code, 401)

    def test_send_message_success(self):
        """Test successful message sending and conversation creation."""
        # Create two users
        self.app.post('/register', data=json.dumps({"username": "userA", "password": "p"}), content_type='application/json')
        self.app.post('/register', data=json.dumps({"username": "userB", "password": "p"}), content_type='application/json')
        
        login_res = self.app.post('/login', data=json.dumps({"username": "userA", "password": "p"}), content_type='application/json')
        token = json.loads(login_res.data)['access_token']

        # Send message
        response = self.app.post('/messages',
                                 data=json.dumps({"recipient_username": "userB", "content": "Hello B!"}),
                                 headers={"Authorization": f"Bearer {token}"},
                                 content_type='application/json')
        
        self.assertEqual(response.status_code, 201)
        data = json.loads(response.data)
        self.assertEqual(data['content'], "Hello B!")
        self.assertEqual(data['sender_username'], "userA")
        self.assertEqual(data['recipient_username'], "userB")

    def test_send_message_recipient_not_found(self):
        """Test sending message to non-existent user."""
        self.app.post('/register', data=json.dumps({"username": "sender", "password": "p"}), content_type='application/json')
        login_res = self.app.post('/login', data=json.dumps({"username": "sender", "password": "p"}), content_type='application/json')
        token = json.loads(login_res.data)['access_token']

        response = self.app.post('/messages',
                                 data=json.dumps({"recipient_username": "ghost", "content": "Hi"}),
                                 headers={"Authorization": f"Bearer {token}"},
                                 content_type='application/json')
        self.assertEqual(response.status_code, 404)

    def test_get_messages_success(self):
        """Test fetching messages from a conversation."""
        # Setup users and conversation
        self.app.post('/register', data=json.dumps({"username": "user1", "password": "p"}), content_type='application/json')
        self.app.post('/register', data=json.dumps({"username": "user2", "password": "p"}), content_type='application/json')
        
        login_res = self.app.post('/login', data=json.dumps({"username": "user1", "password": "p"}), content_type='application/json')
        token = json.loads(login_res.data)['access_token']

        # Create a message to initialize conversation
        msg_res = self.app.post('/messages',
                                 data=json.dumps({"recipient_username": "user2", "content": "Message 1"}),
                                 headers={"Authorization": f"Bearer {token}"},
                                 content_type='application/json')
        
        # Determine the conversation ID from the message check or previous state is hard.
        # However, we can get the list of messages or use a better way.
        # For now, we need to know which conversation was created. 
        # Since the app doesn't return conv_id in MessageResponse, we'll fetch from DB state via a trick 
        # or simply realize that the test needs to know which conversation to ask for.
        # Let's assume we can't change models.py.
        # The most reliable way in the current test is to check what was created.
        
        # Actually, the sender can't see the conversation ID in the response.
        # But we know it's a conversation between user1 and user2.
        # Let's use the actual implementation of conversation creation.
        from models import db, Conversation, Account
        with app.app_context():
            u1 = Account.query.filter_by(username="user1").first()
            u2 = Account.query.filter_by(username="user2").first()
            ids = sorted([u1.id, u2.id])
            conv = Conversation.query.filter_by(account1_id=ids[0], account2_id=ids[1]).first()
            conv_id = conv.id

        # Get messages
        response = self.app.get(f'/messages/{conv_id}', headers={"Authorization": f"Bearer {token}"})
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertTrue(len(data) >= 1)
        self.assertEqual(data[0]['content'], "Message 1")

    def test_get_messages_forbidden(self):
        """Test that a non-participant cannot fetch messages."""
        self.app.post('/register', data=json.dumps({"username": "a", "password": "p"}), content_type='application/json')
        self.app.post('/register', data=json.dumps({"username": "b", "password": "p"}), content_type='application/json')
        self.app.post('/register', data=json.dumps({"username": "c", "password": "p"}), content_type='application/json')
        
        # A sends to B
        login_a = self.app.post('/login', data=json.dumps({"username": "a", "password": "p"}), content_type='application/json')
        token_a = json.loads(login_a.data)['access_token']
        self.app.post('/messages', data=json.dumps({"recipient_username": "b", "content": "secret"}),
                      headers={"Authorization": f"Bearer {token_a}"}, content_type='application/json')
        
        from models import db, Conversation, Account
        with app.app_context():
            ua = Account.query.filter_by(username="a").first()
            ub = Account.query.filter_by(username="b").first()
            ids = sorted([ua.id, ub.id])
            conv = Conversation.query.filter_by(account1_id=ids[0], account2_id=ids[1]).first()
            conv_id = conv.id

        # C tries to read A-B conversation
        login_c = self.app.post('/login', data=json.dumps({"username": "c", "password": "p"}), content_type='application/json')
        token_c = json.loads(login_c.data)['access_token']
        
        response = self.app.get(f'/messages/{conv_id}', headers={"Authorization": f"Bearer {token_c}"})
        self.assertEqual(response.status_code, 403)

    def test_get_conversations_success(self):
        """Test fetching all conversations for a user."""
        # Create user A and B
        self.app.post('/register', data=json.dumps({"username": "userX", "password": "p"}), content_type='application/json')
        self.app.post('/register', data=json.dumps({"username": "userY", "password": "p"}), content_type='application/json')
        
        login_res = self.app.post('/login', data=json.dumps({"username": "userX", "password": "p"}), content_type='application/json')
        token = json.loads(login_res.data)['access_token']

        # Send message to create conversation
        self.app.post('/messages',
                      data=json.dumps({"recipient_username": "userY", "content": "Hi Y"}),
                      headers={"Authorization": f"Bearer {token}"},
                      content_type='application/json')
        
        # Get conversations
        response = self.app.get('/conversations', headers={"Authorization": f"Bearer {token}"})
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(len(data), 1)
        self.assertTrue(
            (data[0]['participant1_username'] == 'userX' and data[0]['participant2_username'] == 'userY') or
            (data[0]['participant1_username'] == 'userY' and data[0]['participant2_username'] == 'userX')
        )

if __name__ == '__main__':
    unittest.main()