from flask_sqlalchemy import SQLAlchemy
from pydantic import BaseModel, ConfigDict, Field
from typing import Optional

db = SQLAlchemy()

# --- Database Models ---
class Account(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)

class Conversation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    account1_id = db.Column(db.Integer, db.ForeignKey('account.id'), nullable=False)
    account2_id = db.Column(db.Integer, db.ForeignKey('account.id'), nullable=False)
    messages = db.relationship('Message', backref='conversation', lazy=True)

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    conversation_id = db.Column(db.Integer, db.ForeignKey('conversation.id'), nullable=False)
    sender_id = db.Column(db.Integer, db.ForeignKey('account.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=db.func.current_timestamp())

# --- Base Pydantic Model ---
class BaseSchema(BaseModel):
    model_config = ConfigDict(
        extra='ignore',
        from_attributes=True,
        populate_by_name=True
    )

    def model_dump_json(self, **kwargs):
        # Ensure null fields are skipped by default unless specified
        kwargs.setdefault('exclude_none', True)
        return super().model_dump_json(**kwargs)

# --- Pydantic Schemas ---
class AccountRegisterSchema(BaseSchema):
    username: str
    password: str

class AccountLoginSchema(BaseSchema):
    username: str
    password: str

class AccountResponseSchema(BaseSchema):
    username: str
    access_token: Optional[str] = None

class AccountUpdateSchema(BaseSchema):
    username: Optional[str] = None
    password: Optional[str] = None

class MessageCreateSchema(BaseSchema):
    recipient_username: str
    content: str

class MessageResponseSchema(BaseSchema):
    id: int
    sender_username: str
    recipient_username: str
    content: str
    timestamp: str

class ConversationResponseSchema(BaseSchema):
    id: int
    participant1_username: str
    participant2_username: str