import logging
import os
from flask import Flask, Response
from models import db
from utils import setup_logging
from routes import api
from messaging_routes import messaging_api

# --- Logging Configuration ---
setup_logging()

app = Flask(__name__)

# --- Database Configuration ---
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'secret-key-for-jwt'

db.init_app(app)
app.register_blueprint(api)
app.register_blueprint(messaging_api)

with app.app_context():
    db.create_all()

# --- Error Handlers ---
@app.errorhandler(404)
def not_found(e):
    return Response(status=404)

# --- Functionality Implementation ---

@app.route('/healthcheck', methods=['GET'])
def healthcheck():
    return Response(status=200)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 6000))
    app.run(port=port, debug=True)