import logging
import datetime
import jwt
import json
from flask import Blueprint, Response, request, current_app
from pydantic import ValidationError

from models import (
    db, Account, 
    AccountRegisterSchema, AccountLoginSchema, AccountResponseSchema, 
    AccountUpdateSchema
)
from utils import get_authenticated_user

api = Blueprint('api', __name__)

@api.route('/login', methods=['POST'])
def login():
    logging.debug("Login endpoint called")
    try:
        data = request.get_json()
        if not data:
            return Response(status=400)

        login_data = AccountLoginSchema(**data)
        user = Account.query.filter_by(username=login_data.username).first()
        
        if not user or user.password != login_data.password:
            logging.warning(f"Login failed for user: {login_data.username}")
            return Response(status=401)

        token = jwt.encode({
            'sub': user.username,
            'iat': datetime.datetime.utcnow(),
            'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24)
        }, current_app.config['SECRET_KEY'], algorithm='HS256')

        response_data = AccountResponseSchema(
            username=user.username,
            access_token=token
        )
        
        return Response(
            response_data.model_dump_json(),
            status=200,
            mimetype='application/json'
        )
    except ValidationError as e:
        logging.warning(f"Validation error: {e}")
        return Response(status=400)
    except Exception as e:
        logging.error(f"Login error: {e}", exc_info=True)
        return Response(status=500)

@api.route('/logout', methods=['POST'])
def logout():
    logging.debug("Logout endpoint called")
    return Response(status=200)

@api.route('/me', methods=['GET'])
def view_account():
    logging.debug("View account endpoint called")
    user = get_authenticated_user()
    if not user:
        return Response(status=401)

    response_data = AccountResponseSchema(username=user.username)
    return Response(
        response_data.model_dump_json(),
        status=200,
        mimetype='application/json'
    )

@api.route('/me', methods=['DELETE'])
def delete_account():
    logging.debug("Delete account endpoint called")
    user = get_authenticated_user()
    if not user:
        return Response(status=401)

    try:
        db.session.delete(user)
        db.session.commit()
        logging.info(f"Account deleted for user: {user.username}")
        return Response(status=204)
    except Exception as e:
        logging.error(f"Deletion error: {e}", exc_info=True)
        db.session.rollback()
        return Response(status=500)

@api.route('/me', methods=['PUT'])
def update_account():
    logging.debug("Update account endpoint called")
    user = get_authenticated_user()
    if not user:
        return Response(status=401)

    try:
        data = request.get_json()
        if not data:
            return Response(status=400)

        update_data = AccountUpdateSchema(**data)
        
        if update_data.username:
            existing = Account.query.filter_by(username=update_data.username).first()
            if existing and existing.id != user.id:
                return Response(status=400)
            user.username = update_data.username
        
        if update_data.password:
            user.password = update_data.password

        db.session.commit()

        response_data = AccountResponseSchema(username=user.username)
        return Response(
            response_data.model_dump_json(),
            status=200,
            mimetype='application/json'
        )
    except ValidationError as e:
        logging.warning(f"Validation error: {e}")
        return Response(status=400)
    except Exception as e:
        logging.error(f"Update error: {e}", exc_info=True)
        db.session.rollback()
        return Response(status=500)

@api.route('/register', methods=['POST'])
def register():
    logging.debug("Register endpoint called")
    try:
        data = request.get_json()
        if not data:
            return Response(status=400)
        
        reg_data = AccountRegisterSchema(**data)
        
        if Account.query.filter_by(username=reg_data.username).first():
            return Response(status=400)

        new_account = Account(username=reg_data.username, password=reg_data.password)
        db.session.add(new_account)
        db.session.commit()

        token = jwt.encode({
            'sub': new_account.username,
            'iat': datetime.datetime.utcnow(),
            'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24)
        }, current_app.config['SECRET_KEY'], algorithm='HS256')

        response_data = AccountResponseSchema(
            username=new_account.username,
            access_token=token
        )
        
        return Response(
            response_data.model_dump_json(),
            status=201,
            mimetype='application/json'
        )
    except ValidationError as e:
        logging.warning(f"Validation error: {e}")
        return Response(status=400)
    except Exception as e:
        logging.error(f"Registration error: {e}", exc_info=True)
        return Response(status=500)

