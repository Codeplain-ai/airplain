import logging
import sys
import jwt
from flask import request, current_app
from models import Account

def setup_logging():
    """
    Configures the logging for the application.
    Sets root logger to DEBUG and others to WARNING.
    """
    logging.basicConfig(level=logging.DEBUG, stream=sys.stdout)
    for logger_name in logging.root.manager.loggerDict:
        logging.getLogger(logger_name).setLevel(logging.WARNING)

def get_authenticated_user():
    """
    Retrieves the authenticated Account based on the Bearer token in the Authorization header.
    Returns None if the token is missing, invalid, or expired.
    """
    auth_header = request.headers.get('Authorization')
    if not auth_header or not auth_header.startswith('Bearer '):
        return None
    
    token = auth_header.split(" ")[1]
    try:
        # Using current_app to access config within the request context
        payload = jwt.decode(
            token, 
            current_app.config['SECRET_KEY'], 
            algorithms=['HS256']
        )
        username = payload.get('sub')
        if not username:
            return None
        return Account.query.filter_by(username=username).first()
    except Exception as e:
        logging.warning(f"JWT validation failed: {str(e)}")
        return None