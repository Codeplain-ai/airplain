import logging
import sys
import datetime
import jwt
import os
from flask import Flask, Response, request
from pydantic import ValidationError
from models import db, Account, AccountRegisterSchema, AccountLoginSchema, AccountResponseSchema, AccountUpdateSchema

# --- Logging Configuration ---
# Set root logger to DEBUG, all others to WARN
logging.basicConfig(level=logging.DEBUG, stream=sys.stdout)
for logger_name in logging.root.manager.loggerDict:
    logging.getLogger(logger_name).setLevel(logging.WARNING)

app = Flask(__name__)

# --- Database Configuration ---
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'secret-key-for-jwt'

db.init_app(app)

with app.app_context():
    db.create_all()

# --- Error Handlers ---
@app.errorhandler(404)
def not_found(e):
    # Return 404 status code with empty body
    return Response(status=404)

# --- Helper Functions ---
def get_authenticated_user():
    auth_header = request.headers.get('Authorization')
    if not auth_header or not auth_header.startswith('Bearer '):
        return None
    
    token = auth_header.split(" ")[1]
    try:
        payload = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
        username = payload.get('sub')
        return Account.query.filter_by(username=username).first()
    except Exception as e:
        logging.warning(f"JWT validation failed: {e}")
        return None

# --- Functionality Implementation ---
@app.route('/login', methods=['POST'])
def login():
    """
    Allows a user to login to an Account.
    """
    logging.debug("Login endpoint called")
    try:
        data = request.get_json()
        if not data:
            return Response(status=400)

        login_data = AccountLoginSchema(**data)
        
        user = Account.query.filter_by(username=login_data.username).first()
        
        if not user or user.password != login_data.password:
            logging.warning(f"Login failed for user: {login_data.username}")
            return Response(status=401)

        # Generate AccessToken (JWT)
        token = jwt.encode({
            'sub': user.username,
            'iat': datetime.datetime.utcnow(),
            'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24)
        }, app.config['SECRET_KEY'], algorithm='HS256')

        response_data = AccountResponseSchema(
            username=user.username,
            access_token=token
        )
        
        return Response(
            response_data.model_dump_json(),
            status=200,
            mimetype='application/json'
        )
    except ValidationError as e:
        logging.warning(f"Validation error: {e}")
        return Response(status=400)
    except Exception as e:
        logging.error(f"Login error: {e}")
        return Response(status=500)

@app.route('/logout', methods=['POST'])
def logout():
    """
    Allows a user to logout from an Account.
    """
    logging.debug("Logout endpoint called")
    return Response(status=200)

@app.route('/me', methods=['GET'])
def view_account():
    """
    Allows a user to view their Account.
    """
    logging.debug("View account endpoint called")
    user = get_authenticated_user()
    if not user:
        return Response(status=401)

    response_data = AccountResponseSchema(username=user.username)
    return Response(
        response_data.model_dump_json(),
        status=200,
        mimetype='application/json'
    )

@app.route('/me', methods=['DELETE'])
def delete_account():
    """
    Allows a user to delete their Account.
    """
    logging.debug("Delete account endpoint called")
    user = get_authenticated_user()
    if not user:
        return Response(status=401)

    try:
        db.session.delete(user)
        db.session.commit()
        logging.info(f"Account deleted for user: {user.username}")
        return Response(status=204)
    except Exception as e:
        logging.error(f"Deletion error: {e}")
        db.session.rollback()
        return Response(status=500)

@app.route('/me', methods=['PUT'])
def update_account():
    """
    Allows a user to update their Account.
    """
    logging.debug("Update account endpoint called")
    user = get_authenticated_user()
    if not user:
        return Response(status=401)

    try:
        data = request.get_json()
        if not data:
            return Response(status=400)

        update_data = AccountUpdateSchema(**data)
        
        if update_data.username:
            # Check if username is taken by someone else
            existing = Account.query.filter_by(username=update_data.username).first()
            if existing and existing.id != user.id:
                return Response(status=400)
            user.username = update_data.username
        
        if update_data.password:
            user.password = update_data.password

        db.session.commit()

        response_data = AccountResponseSchema(username=user.username)
        return Response(
            response_data.model_dump_json(),
            status=200,
            mimetype='application/json'
        )
    except ValidationError as e:
        logging.warning(f"Validation error: {e}")
        return Response(status=400)
    except Exception as e:
        logging.error(f"Update error: {e}")
        db.session.rollback()
        return Response(status=500)

@app.route('/register', methods=['POST'])
def register():
    """
    Allows a user to register an Account.
    """
    logging.debug("Register endpoint called")
    try:
        data = request.get_json()
        if not data:
            return Response(status=400)
        
        # Validation
        reg_data = AccountRegisterSchema(**data)
        
        # Check if user exists
        if Account.query.filter_by(username=reg_data.username).first():
            return Response(status=400)

        # Create user
        new_account = Account(username=reg_data.username, password=reg_data.password)
        db.session.add(new_account)
        db.session.commit()

        # Generate AccessToken (JWT)
        token = jwt.encode({
            'sub': new_account.username,
            'iat': datetime.datetime.utcnow(),
            'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24)
        }, app.config['SECRET_KEY'], algorithm='HS256')

        response_data = AccountResponseSchema(
            username=new_account.username,
            access_token=token
        )
        
        return Response(
            response_data.model_dump_json(),
            status=201,
            mimetype='application/json'
        )
    except ValidationError as e:
        logging.warning(f"Validation error: {e}")
        return Response(status=400)
    except Exception as e:
        logging.error(f"Registration error: {e}")
        return Response(status=500)

@app.route('/healthcheck', methods=['GET'])
def healthcheck():
    """
    Returns 200 status code if the App is running.
    """
    logging.debug("Healthcheck endpoint called")
    return Response(status=200)

if __name__ == '__main__':
    # Default listen to port 6000, allow override for tests
    port = int(os.environ.get('PORT', 6000))
    app.run(port=port, debug=True)