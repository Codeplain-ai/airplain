from flask_sqlalchemy import SQLAlchemy
from pydantic import BaseModel, ConfigDict, Field
from typing import Optional

db = SQLAlchemy()

# --- Database Models ---
class Account(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)

# --- Base Pydantic Model ---
class BaseSchema(BaseModel):
    model_config = ConfigDict(
        extra='ignore',
        from_attributes=True,
        populate_by_name=True
    )

    def model_dump_json(self, **kwargs):
        # Ensure null fields are skipped by default unless specified
        kwargs.setdefault('exclude_none', True)
        return super().model_dump_json(**kwargs)

# --- Pydantic Schemas ---
class AccountRegisterSchema(BaseSchema):
    username: str
    password: str

class AccountLoginSchema(BaseSchema):
    username: str
    password: str

class AccountResponseSchema(BaseSchema):
    username: str
    access_token: Optional[str] = None

class AccountUpdateSchema(BaseSchema):
    username: Optional[str] = None
    password: Optional[str] = None