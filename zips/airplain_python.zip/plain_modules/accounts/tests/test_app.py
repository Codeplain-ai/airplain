import unittest
import json
import sys
import os

# Add the parent directory to sys.path to allow importing app
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app

class TestApp(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True

    def test_healthcheck_success(self):
        """Test that /healthcheck returns 200 OK."""
        response = self.app.get('/healthcheck')
        self.assertEqual(response.status_code, 200)

    def test_unknown_endpoint_returns_404_empty_body(self):
        """Test that unknown endpoints return 404 and empty body."""
        response = self.app.get('/invalid-route-12345')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.data, b"")

    def test_login_success(self):
        """Test successful login."""
        # First register
        self.app.post('/register', 
                      data=json.dumps({"username": "testuser", "password": "password123"}),
                      content_type='application/json')
        
        # Then login
        response = self.app.post('/login',
                                 data=json.dumps({"username": "testuser", "password": "password123"}),
                                 content_type='application/json')
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['username'], 'testuser')
        self.assertIn('access_token', data)

    def test_login_failure_invalid_credentials(self):
        """Test login with wrong password."""
        self.app.post('/register', 
                      data=json.dumps({"username": "user2", "password": "password123"}),
                      content_type='application/json')
        
        response = self.app.post('/login',
                                 data=json.dumps({"username": "user2", "password": "wrongpassword"}),
                                 content_type='application/json')
        self.assertEqual(response.status_code, 401)

    def test_logout_success(self):
        """Test successful logout."""
        response = self.app.post('/logout')
        self.assertEqual(response.status_code, 200)

    def test_update_account_success(self):
        """Test updating account details."""
        # Register and login to get token
        self.app.post('/register', 
                      data=json.dumps({"username": "updateuser", "password": "oldpassword"}),
                      content_type='application/json')
        login_res = self.app.post('/login',
                                  data=json.dumps({"username": "updateuser", "password": "oldpassword"}),
                                  content_type='application/json')
        token = json.loads(login_res.data)['access_token']

        # Update username
        response = self.app.put('/me',
                                data=json.dumps({"username": "newusername"}),
                                headers={"Authorization": f"Bearer {token}"},
                                content_type='application/json')
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['username'], 'newusername')

    def test_update_account_unauthorized(self):
        """Test updating account without token."""
        response = self.app.put('/me',
                                data=json.dumps({"username": "hacker"}),
                                content_type='application/json')
        self.assertEqual(response.status_code, 401)

    def test_view_account_success(self):
        """Test viewing account details."""
        # Register and login
        username = "viewuser"
        self.app.post('/register', 
                      data=json.dumps({"username": username, "password": "password123"}),
                      content_type='application/json')
        login_res = self.app.post('/login',
                                  data=json.dumps({"username": username, "password": "password123"}),
                                  content_type='application/json')
        token = json.loads(login_res.data)['access_token']

        # View account
        response = self.app.get('/me',
                                headers={"Authorization": f"Bearer {token}"})
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['username'], username)

    def test_view_account_unauthorized(self):
        """Test viewing account without token."""
        response = self.app.get('/me')
        self.assertEqual(response.status_code, 401)

    def test_delete_account_success(self):
        """Test successful account deletion."""
        # Register and login
        username = "deleteuser"
        self.app.post('/register', 
                      data=json.dumps({"username": username, "password": "password123"}),
                      content_type='application/json')
        login_res = self.app.post('/login',
                                  data=json.dumps({"username": username, "password": "password123"}),
                                  content_type='application/json')
        token = json.loads(login_res.data)['access_token']

        # Delete account
        response = self.app.delete('/me',
                                   headers={"Authorization": f"Bearer {token}"})
        self.assertEqual(response.status_code, 204)

        # Verify account is gone (login should fail)
        login_fail = self.app.post('/login',
                                   data=json.dumps({"username": username, "password": "password123"}),
                                   content_type='application/json')
        self.assertEqual(login_fail.status_code, 401)

    def test_delete_account_unauthorized(self):
        """Test deleting account without token."""
        response = self.app.delete('/me')
        self.assertEqual(response.status_code, 401)

if __name__ == '__main__':
    unittest.main()