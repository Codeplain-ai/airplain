import unittest
import sys
import os

# Add the parent directory to sys.path to allow importing app
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app

class TestApp(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True

    def test_healthcheck_success(self):
        """Test that /healthcheck returns 200 OK."""
        response = self.app.get('/healthcheck')
        self.assertEqual(response.status_code, 200)

    def test_unknown_endpoint_returns_404_empty_body(self):
        """Test that unknown endpoints return 404 and empty body."""
        response = self.app.get('/invalid-route-12345')
        self.assertEqual(response.status_code, 404)
        self.assertEqual(response.data, b"")

if __name__ == '__main__':
    unittest.main()