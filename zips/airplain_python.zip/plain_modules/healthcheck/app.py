import logging
import sys
from flask import Flask, Response
from flask_sqlalchemy import SQLAlchemy
from pydantic import BaseModel, ConfigDict

# --- Logging Configuration ---
# Set root logger to DEBUG, all others to WARN
logging.basicConfig(level=logging.DEBUG, stream=sys.stdout)
for logger_name in logging.root.manager.loggerDict:
    logging.getLogger(logger_name).setLevel(logging.WARNING)

app = Flask(__name__)

# --- Database Configuration ---
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# --- Base Pydantic Model ---
class BaseSchema(BaseModel):
    model_config = ConfigDict(
        extra='ignore',
        from_attributes=True,
        populate_by_name=True
    )

    def model_dump_json(self, **kwargs):
        # Ensure null fields are skipped by default unless specified
        kwargs.setdefault('exclude_none', True)
        return super().model_dump_json(**kwargs)

# --- Error Handlers ---
@app.errorhandler(404)
def not_found(e):
    # Return 404 status code with empty body
    return Response(status=404)

# --- Functionality Implementation ---
@app.route('/healthcheck', methods=['GET'])
def healthcheck():
    """
    Returns 200 status code if the App is running.
    """
    logging.debug("Healthcheck endpoint called")
    return Response(status=200)

if __name__ == '__main__':
    # Default listen to port 6000
    app.run(port=6000, debug=True)